package com.example.reminder

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
