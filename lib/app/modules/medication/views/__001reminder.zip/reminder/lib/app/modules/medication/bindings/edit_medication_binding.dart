import 'package:get/get.dart';
import '../controllers/edit_medication_controller.dart';

class EditMedicationBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<EditMedicationController>(
      () => EditMedicationController(
        updateMedicationUseCase: Get.find(),
        updateReminderUseCase: Get.find(),
      ),
    );
  }
}
