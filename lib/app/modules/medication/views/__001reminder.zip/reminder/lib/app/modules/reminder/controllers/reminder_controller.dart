import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:logger/logger.dart';
import '../../../data/models/reminder_model.dart';
import '../../../data/models/reminder_state.dart';
import '../../../data/models/reminder_status.dart';
import '../../../data/services/reminder_service.dart';

class ReminderController extends GetxController {
  final _logger = Logger();
  final _reminderService = Get.find<ReminderService>();
  
  final reminders = <ReminderModel>[].obs;
  final isLoading = false.obs;
  final error = ''.obs;
  final selectedDate = DateTime.now().obs;

  @override
  void onInit() {
    super.onInit();
    loadDayReminders();
  }

  ReminderStatus getStatus(ReminderModel reminder){
    final selectStatus = DateTime(selectedDate.value.year,selectedDate.value.month,selectedDate.value.day,reminder.dateTime.hour,reminder.dateTime.minute,reminder.dateTime.second,reminder.dateTime.millisecond,reminder.dateTime.microsecond);
    for(ReminderStatus status in reminder.statusHistory){
      if(status.timestamp == selectStatus){
        return status;
      }
    }
    return ReminderStatus(timestamp: DateTime.now(), state: ReminderState.pending);
  }

  Future<void> loadDayReminders() async {
    try {
      isLoading.value = true;
      error.value = '';

      final dayReminders = await _reminderService.getDayReminders(selectedDate.value);
      reminders.assignAll(dayReminders);
      _logger.i('Loaded ${reminders.length} reminders for ${selectedDate.value}');
    } catch (e) {
      error.value = 'Failed to load reminders';
      _logger.e('Error loading reminders: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> selectDate(DateTime date) async {
    selectedDate.value = date;
    await loadDayReminders();

  }

  Future<void> createReminder(ReminderModel model) async {
    try {
      isLoading.value = true;
      error.value = '';

      final success = await _reminderService.saveReminder(model);
      if (success) {
        await loadDayReminders(); // Refresh the list
        _logger.i('Created reminder for medication: ${model.medicationId}');
      } else {
        error.value = 'Failed to create reminder';
      }
    } catch (e) {
      error.value = 'Failed to create reminder';
      _logger.e('Error creating reminder: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateReminderStatus(String id, ReminderStatus newState) async {
    try {
      isLoading.value = true;
      error.value = '';


      final success = await _reminderService.updateReminderStatus(id, newState);
      if (success) {
        await loadDayReminders(); // Refresh the list
        _logger.i('Updated reminder status: $id');
      } else {
        error.value = 'Failed to update reminder status';
      }
    } catch (e) {
      error.value = 'Failed to update reminder status';
      _logger.e('Error updating reminder status: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> deleteReminder(String id) async {
    try {
      isLoading.value = true;
      error.value = '';

      final success = await _reminderService.deleteReminder(id);
      if (success) {
        await loadDayReminders(); // Refresh the list
        _logger.i('Deleted reminder: $id');
      } else {
        error.value = 'Failed to delete reminder';
      }
    } catch (e) {
      error.value = 'Failed to delete reminder';
      _logger.e('Error deleting reminder: $e');
    } finally {
      isLoading.value = false;
    }
  }
}
