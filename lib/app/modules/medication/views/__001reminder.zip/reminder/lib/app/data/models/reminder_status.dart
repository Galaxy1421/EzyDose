import 'reminder_state.dart';

class ReminderStatus {
  final DateTime timestamp;
  final ReminderState state;

  ReminderStatus({
    required this.timestamp,
    required this.state,
  });

  Map<String, dynamic> toJson() {
    return {
      'timestamp': timestamp.toIso8601String(),
      'state': state.toString().split('.').last,
    };
  }

  factory ReminderStatus.fromJson(Map<String, dynamic> json) {
    return ReminderStatus(
      timestamp: DateTime.parse(json['timestamp']),
      state: ReminderState.values.firstWhere(
        (e) => e.toString().split('.').last == json['state'],
      ),
    );
  }
}
