import 'package:get/get.dart';
import 'package:reminder/app/data/services/medication_service.dart';
import '../../auth/controllers/auth_controller.dart';
import '../../medication/controllers/medication_controller.dart';
import '../controllers/reminder_controller.dart';
import '../../../data/services/reminder_service.dart';

class ReminderBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<ReminderService>(ReminderService());
    Get.put<MedicationService>(MedicationService());
    Get.put<MedicationController>(MedicationController());
    Get.put<AuthController>(AuthController());
    Get.put<ReminderController>(ReminderController());
  }
}
