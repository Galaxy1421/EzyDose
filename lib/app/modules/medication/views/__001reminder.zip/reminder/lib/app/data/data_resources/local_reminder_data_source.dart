import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:reminder/app/data/models/reminder_model.dart';



abstract class LocalReminderDataSource {
  Future<List<ReminderModel>> getAllReminders();
  Future<List<ReminderModel>> getReminderByMedcationId(String id);
  Future<void> addReminder(ReminderModel model);
  Future<void> getReminder(String id);
  Future<void> removeReminder(ReminderModel model);
  Future<void> updateReminder(ReminderModel model);
}
class LocalReminderDatSourceImpl extends LocalReminderDataSource {
  final String boxName = "local_reminders";
  late final GetStorage _box;

  LocalReminderDatSourceImpl() {
    _box = GetStorage(boxName);
  }

  @override
  Future<List<ReminderModel>> getAllReminders() async {
    try {
      final List<dynamic> rawList = _box.read('reminders') ?? [];
      return rawList.map((item) => ReminderModel.fromJson(item)).toList();
    } catch (e) {
      print('Error getting all reminders: $e');
      return [];
    }
  }

  @override
  Future<void> addReminder(ReminderModel model) async {
    try {
      List<dynamic> reminders = _box.read('reminders') ?? [];
      reminders.add(model.toJson());
      await _box.write('reminders', reminders);
    } catch (e) {
      print('Error adding reminder: $e');
      throw e;
    }
  }

  @override
  Future<void> removeReminder(ReminderModel model) async {
    try {
      List<dynamic> reminders = _box.read('reminders') ?? [];
      reminders.removeWhere((item) =>
      ReminderModel.fromJson(item).id == model.id
      );
      await _box.write('reminders', reminders);
    } catch (e) {
      print('Error removing reminder: $e');
      throw e;
    }
  }
  @override
  Future<void> removeMedicationReminders(String medicationId) async {
    try {
      List<dynamic> reminders = _box.read('reminders') ?? [];
      reminders.removeWhere((item) =>
      ReminderModel.fromJson(item).medicationId == medicationId
      );
      await _box.write('reminders', reminders);
    } catch (e) {
      print('Error removing reminder: $e');
      throw e;
    }
  }

  @override
  Future<void> updateReminder(ReminderModel model) async {
    try {
      List<dynamic> reminders = _box.read('reminders') ?? [];
      int index = reminders.indexWhere((item) =>
      ReminderModel.fromJson(item).id == model.id
      );
      if (index != -1) {
        reminders[index] = model.toJson();
        await _box.write('reminders', reminders);
      } else {
        throw Exception('Reminder not found');
      }
    } catch (e) {
      print('Error updating reminder: $e');
      throw e;
    }
  }

  @override
  Future<List<ReminderModel>> getReminderByMedcationId(String id) async {
    try {
      List<dynamic> reminders = _box.read('reminders') ?? [];
      return reminders
          .map((item) => ReminderModel.fromJson(item))
          .where((reminder) => reminder.medicationId == id)
          .toList();
    } catch (e) {
      print('Error getting reminders by medication ID: $e');
      return [];
    }
  }

  @override
  Future<ReminderModel?> getReminder(String id) async {
    try {
      List<dynamic> reminders = _box.read('reminders') ?? [];
      return reminders
          .map((item) => ReminderModel.fromJson(item))
          .firstWhere((reminder) => reminder.id == id);
    } catch (e) {
      print('Error getting reminder by ID: $e');
      return null;
    }
  }

}