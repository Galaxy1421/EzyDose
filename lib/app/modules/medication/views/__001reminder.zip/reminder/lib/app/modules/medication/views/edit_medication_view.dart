import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart' as intl;
import 'package:reminder/app/modules/medication/controllers/add_medication_controller.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/medication_model.dart';
import '../../../data/models/reminder_model.dart';
import '../../../data/services/routine_service.dart';
import '../../../data/services/interaction_service.dart';
import '../../../data/models/interaction_model.dart';
import '../controllers/edit_medication_controller.dart';

class EditMedicationView extends GetView<AddMedicationController> {
  final MedicationModel medication;

  EditMedicationView({  
    Key? key,
    required this.medication,
  }) : super(key: key) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      Get.find<EditMedicationController>().loadMedication(medication);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: Get.locale?.languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: AppColors.background,
        appBar: _buildAppBar(),
        body: Obx(() {
          return controller.currentTab.value == 0
              ? _buildBody()
              : _buildRemindersTab();
        }),
      ),
    );
  }

  Widget _buildBody() {
    return SingleChildScrollView(
      child: Form(
        key: controller.formKey,
        child: Column(
          children: [
            _buildHeader(),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildMedicationNameField(),
                  const SizedBox(height: 24),
                  _buildMedicationImage(),
                  // const SizedBox(height: 10),
                  _buildQuantityFields(),
                  const SizedBox(height: 24),
                  _buildExpiryDateField(),
                  const SizedBox(height: 24),
                  _buildPrescriptionSection(),
                  const SizedBox(height: 24),
                  _buildInteractionsSection(),
                  const SizedBox(height: 24),
                  _buildNextButton(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRemindersTab() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionTitle('reminders'.tr, Icons.alarm),
            const SizedBox(height: 32),
            _buildFrequencySelector(),
            const SizedBox(height: 16),
            _buildReminderTypeGrid(),
            const SizedBox(height: 16),
            _buildCustomTimeButton(),
            const SizedBox(height: 16),
            _buildNewRemindersList(),

            const SizedBox(height: 32),
            _buildNavigationButtons(),
          ],
        ),
      ),
    );
  }

  Widget _buildReminderTypeGrid() {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 2.5,
      children: [
        _buildReminderTypeCard(ReminderType.wakeUp, 'wake_up'.tr, Icons.wb_sunny),
        _buildReminderTypeCard(ReminderType.beforeBreakfast, 'before_breakfast'.tr, Icons.arrow_upward),
        _buildReminderTypeCard(ReminderType.afterBreakfast, 'after_breakfast'.tr, Icons.arrow_downward),
        _buildReminderTypeCard(ReminderType.beforeLunch, 'before_lunch'.tr, Icons.arrow_upward),
        _buildReminderTypeCard(ReminderType.afterLunch, 'after_lunch'.tr, Icons.arrow_downward),
        _buildReminderTypeCard(ReminderType.beforeDinner, 'before_dinner'.tr, Icons.arrow_upward),
        _buildReminderTypeCard(ReminderType.afterDinner, 'after_dinner'.tr, Icons.arrow_downward),
        _buildReminderTypeCard(ReminderType.bedtime, 'bedtime'.tr, Icons.nightlight),
      ],
    );
  }

  Widget _buildReminderTypeCard(ReminderType type, String label, IconData icon) {
    return Obx(() {
      final bool isSelected = controller.reminders.any((r) => r.type == type);
      return InkWell(
        onTap: () {
          if(isSelected){
            controller.removeReminder(
                controller.reminders.indexWhere((r) => r.type == type)
            );
          }else
            controller.addReminder(TimeOfDay.now(), type: type);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? AppColors.primary.withOpacity(0.1) : Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected ? AppColors.primary : Colors.grey.shade300,
              width: isSelected ? 2 : 1,
            ),
            boxShadow: [
              if (!isSelected)
                BoxShadow(
                  color: Colors.grey.withOpacity(0.1),
                  spreadRadius: 0,
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
            ],
          ),
          child: Stack(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    icon,
                    color: isSelected ? AppColors.primary : AppColors.textLight,
                    size: 20,
                  ),
                  const SizedBox(width: 8),
                  Flexible(
                    child: Text(
                      label,
                      style: GoogleFonts.poppins(
                        fontSize: 12,
                        fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                        color: isSelected ? AppColors.primary : AppColors.textDark,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
              if (isSelected)
                Positioned(
                  right: -8,
                  top: -8,
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        controller.removeReminder(
                          controller.reminders.indexWhere((r) => r.type == type)
                        );
                      },
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          Icons.close,
                          size: 16,
                          color: Colors.red,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }

  Widget _buildCustomTimeButton() {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: () async {
          final TimeOfDay? time = await showTimePicker(
            context: Get.context!,
            initialTime: TimeOfDay.now(),
          );
          if (time != null) {
            controller.onTimeSelected(time);
          }
        },
        icon: const Icon(Icons.access_time,color: Colors.white,),
        label:  Text('add_custom_time'.tr,style: TextStyle(color: Colors.white),),
        style: OutlinedButton.styleFrom(
          backgroundColor: AppColors.primary,
          padding: const EdgeInsets.symmetric(vertical: 12),
          // side: BorderSide(color: Get.theme.primaryColor),
        ),
      ),
    );
  }

  Widget _buildAddReminderButton() {
    return ElevatedButton.icon(
      onPressed: () async {
        final TimeOfDay? time = await showTimePicker(
          context: Get.context!,
          initialTime: TimeOfDay.now(),
        );
        if (time != null) {
          controller.onTimeSelected(time);
        }
      },
      icon: const Icon(Icons.add),
      label: const Text('Add Reminder'),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      ),
    );
  }

  Widget _buildNewRemindersList() {
    return Obx(() {
      if (controller.reminders.isEmpty) {
        return const Center(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Text(
              'No reminders added yet',
              style: TextStyle(
                color: Colors.grey,
                fontSize: 16,
              ),
            ),
          ),
        );
      }

      return ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: controller.reminders.length,
        itemBuilder: (context, index) {
          final reminder = controller.reminders[index];
          return _buildReminderItem(reminder);
        },
      );
    });
  }

  Widget _buildReminderItem(ReminderModel reminder) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: ListTile(
        leading: Icon(
          Icons.alarm,
          color: AppColors.primary,
        ),
        title: Text(
          _getReminderTypeText(reminder.type),
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          controller.getFormattedReminderTime(reminder.dateTime),
          style: TextStyle(
            color: Colors.grey.shade600,
          ),
        ),
        trailing: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => controller.removeReminder(
            controller.reminders.indexOf(reminder),
          ),
          color: Colors.grey.shade600,
        ),
      ),
    );
  }

  Widget _buildNavigationButtons() {
    return Obx(() => Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        if (controller.currentTab.value == 1)
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),

            onPressed: controller.onPreviousTabPressed,
            child:  Text('previous'.tr,style: TextStyle(color: Colors.white,fontSize: 16,),),
          ),
        const SizedBox(width: 10,),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          onPressed: controller.currentTab.value == 0
              ? controller.onNextTabPressed
              : controller.onSavePressed,
          child: Text(controller.currentTab.value == 0 ? 'next'.tr : 'save'.tr,style: TextStyle(color: Colors.white,fontSize: 16),),
        ),
      ],
    ));
  }

  Widget _buildNextButton() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          if (controller.formKey.currentState!.validate()) {
            controller.currentTab.value = 1;
            controller.generateReminders();
          }
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text(
          'next'.tr,
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      leading: IconButton(
        icon: Icon(
          Get.locale?.languageCode == 'ar' ? Icons.arrow_back_ios_new : Icons.arrow_back_ios, 
          color: Colors.white
        ),
        onPressed: () {
          if (controller.currentTab.value == 1) {
            controller.currentTab.value = 0;
          } else {
            Get.back();
          }
        },
      ),
      flexibleSpace: Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient,
        ),
      ),
      title: Obx(() => Text(
        controller.currentTab.value == 0
            ? (controller.isEditing.value ? 'edit_medication'.tr : 'add_medication'.tr)
            : 'set_reminders'.tr,
        style: GoogleFonts.poppins(
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
      )),
    );
  }

  Widget _buildHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 10, 20, 20),
      decoration: BoxDecoration(
        gradient: AppColors.primaryGradient,
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      child: Column(
        children: [
          Text(
            controller.isEditing.value 
                ? 'update_medication_details'.tr 
                : 'add_new_medication'.tr,
            style: GoogleFonts.poppins(
              color: Colors.white.withOpacity(0.9),
              fontSize: 16,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildMedicationNameField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'medication_name'.tr,
          style: GoogleFonts.poppins(
            color: Colors.black87,
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 8),
        Obx(() {
          final suggestions = controller.searchResults;
          return Column(
            children: [
              _buildInputContainer(
                child: TextField(
                  controller: controller.nameController,
                  onChanged: controller.onSearchChanged,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    color: AppColors.text,
                  ),
                  decoration: _buildInputDecoration(
                    'enter_medication_name'.tr,
                    Icons.search_rounded,
                  ),
                ),
              ),
              if (suggestions.isNotEmpty)
                Container(
                  margin: const EdgeInsets.only(top: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 15,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: ListView.builder(
                      shrinkWrap: true,
                      padding: EdgeInsets.zero,
                      itemCount: suggestions.length,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        final medication = suggestions[index];

                        return Column(
                          children: [
                            if (index > 0)
                              Divider(
                                height: 1,
                                color: Colors.grey.shade100,
                              ),
                            ListTile(
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 8,
                              ),
                              onTap: () {
                                controller.onMedicationSelected(medication);
                              },
                              leading: Container(
                                width: 45,
                                height: 45,
                                decoration: BoxDecoration(
                                  color: AppColors.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: medication.imageUrl == null
                                    ? Icon(
                                        Icons.medication,
                                        color: AppColors.primary,
                                        size: 24,
                                      )
                                    : Image.asset(medication.imageUrl!),
                              ),
                              title: Text(
                                medication.name,
                                style: GoogleFonts.poppins(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.text,
                                ),
                              ),
                              subtitle: Text(
                                medication.instructions,
                                style: GoogleFonts.poppins(
                                  fontSize: 13,
                                  color: Colors.grey.shade600,
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
            ],
          );
        }),
      ],
    );
  }

  Widget _buildMedicationImage() {
    return Obx(() {
      final imageUrl = controller.medication.value.imageBase64;
      if (imageUrl == null) return SizedBox.shrink();
      
      return Container(
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey.shade300),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.asset(
            imageUrl,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return Center(
                child: Icon(
                  Icons.medication,
                  size: 64,
                  color: AppColors.primary,
                ),
              );
            },
          ),
        ),
      );
    });
  }

  Widget _buildQuantityFields() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('quantity'.tr, Icons.format_list_numbered),
        const SizedBox(height: 12),
        Column(
          children: [
            _buildInputContainer(
              child: TextFormField(
                controller: controller.totalQuantityController,
                keyboardType: TextInputType.number,
                decoration: _buildInputDecoration('total_quantity'.tr, Icons.medication_outlined),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'quantity_required'.tr;
                  }
                  if (int.tryParse(value) == null || int.parse(value) <= 0) {
                    return 'please_enter_valid_number'.tr;
                  }
                  return null;
                },
              ),
            ),

            const SizedBox(height: 12),
            _buildSectionTitle('dose_amount'.tr, Icons.ac_unit_rounded),
            const SizedBox(height: 12),
            _buildInputContainer(
              child: TextFormField(
                controller: controller.doseQuantityController,
                keyboardType: TextInputType.number,
                decoration: _buildInputDecoration('dose_amount'.tr, Icons.local_hospital_outlined),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'required'.tr;
                  }
                  if (int.tryParse(value) == null || int.parse(value) <= 0) {
                    return 'invalid'.tr;
                  }
                  return null;
                },
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildExpiryDateField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('expiry_date'.tr, Icons.event),
        const SizedBox(height: 12),
        _buildInputContainer(
          child: InkWell(
            onTap: () async {
              final date = await showDatePicker(
                context: Get.context!,
                initialDate: DateTime.now().add(const Duration(days: 365)),
                firstDate: DateTime.now(),
                lastDate: DateTime.now().add(const Duration(days: 3650)),
              );
              if (date != null) {
                controller.expiryDate.value = date;
              }
            },
            child: Obx(() => Padding(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              child: Row(
                children: [
                  Icon(
                    Icons.event,
                    color: AppColors.textLight,
                  ),
                  const SizedBox(width: 12),
                  Text(
                    controller.expiryDate.value != null
                        ? '${controller.expiryDate.value!.day}/${controller.expiryDate.value!.month}/${controller.expiryDate.value!.year}'
                        : 'select_expiry_date'.tr,
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: controller.expiryDate.value != null
                          ? AppColors.text
                          : AppColors.textLight,
                    ),
                  ),
                ],
              ),
            )),
          ),
        ),
      ],
    );
  }

  Widget _buildReminderTimesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('reminders'.tr, Icons.alarm),


        _buildReminderFrequencySelector(),
        const SizedBox(height: 16),
        _buildReminderTypeSelector(),
        const SizedBox(height: 16),
        _buildSelectedReminders(),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildReminderFrequencySelector() {
    return Container(
      width: Get.width,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            'repeat'.tr,
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: AppColors.text,
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: ReminderFrequency.values.map((frequency) {
              return Obx(() {
                final bool isSelected = controller.selectedFrequency.value == frequency;
                return InkWell(
                  onTap: () => controller.updateReminderFrequency(frequency),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? AppColors.primary
                          : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: isSelected
                            ? AppColors.primary
                            : Colors.grey.shade300,
                        width: 1,
                      ),
                    ),
                    child: Text(
                      controller.getFrequencyLabel(frequency),
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: isSelected
                            ? FontWeight.w600
                            : FontWeight.w500,
                        color: isSelected
                            ? Colors.white
                            : Colors.grey.shade600,
                      ),
                    ),
                  ),
                );
              });
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildReminderTypeSelector() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(Icons.access_time, color: AppColors.primary),
                const SizedBox(width: 12),
                Text(
                  'Reminder Times',
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppColors.text,
                  ),
                ),
              ],
            ),
          ),

          // Frequency Selector
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Icon(Icons.repeat, color: Colors.grey.shade600, size: 20),
                const SizedBox(width: 8),
                Text(
                  'Frequency:',
                  style: TextStyle(color: Colors.grey.shade600),
                ),
                const SizedBox(width: 12),
                Obx(() {
                  return ChoiceChip(
                    label: Text('Daily'),
                    selected: controller.selectedFrequency.value == ReminderFrequency.daily,
                    onSelected: (selected) {
                      if (selected) controller.updateReminderFrequency(ReminderFrequency.daily);
                    },
                  );
                }),
                const SizedBox(width: 8),
                Obx(() {
                  return ChoiceChip(
                    label: Text('Custom'),
                    selected: controller.selectedFrequency.value == ReminderFrequency.custom,
                    onSelected: (selected) {
                      if (selected) controller.updateReminderFrequency(ReminderFrequency.custom);
                    },
                  );
                }),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Reminder Types Grid
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            childAspectRatio: 2.5,
            padding: const EdgeInsets.all(16),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            children: ReminderType.values.where((type) => type != ReminderType.custom).map((type) {
              return Obx(() {
                final bool isSelected = controller.newReminders
                    .any((reminder) => reminder.type == type);
                return InkWell(
                  onTap: () => _addReminderWithRoutineTime(type),
                  child: Container(
                    decoration: BoxDecoration(
                      color: isSelected ? AppColors.primary.withOpacity(0.1) : Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? AppColors.primary : Colors.grey.shade300,
                        width: 1,
                      ),
                    ),
                    child: Stack(
                      children: [
                        Center(
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                _getReminderTypeIcon(type),
                                color: isSelected ? AppColors.primary : Colors.grey.shade600,
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _getReminderTypeLabel(type),
                                  style: TextStyle(
                                    color: isSelected ? AppColors.primary : Colors.grey.shade600,
                                    fontSize: 13,
                                    overflow: TextOverflow.ellipsis,
                                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (isSelected)
                          Positioned(
                            top: 4,
                            right: 4,
                            child: Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: AppColors.primary,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                );
              });
            }).toList(),
          ),

          // Custom Time Button
          Padding(
            padding: const EdgeInsets.all(16),
            child: ElevatedButton.icon(
              onPressed: () => _addReminderWithRoutineTime(ReminderType.custom),
              icon: Icon(Icons.add_alarm),
              label: Text('add_custom_time'.tr),
              style: ElevatedButton.styleFrom(
                minimumSize: Size(double.infinity, 48),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  IconData _getReminderTypeIcon(ReminderType type) {
    switch (type) {
      case ReminderType.wakeUp:
        return Icons.wb_sunny;
      case ReminderType.breakfast:
        return Icons.free_breakfast;
      case ReminderType.beforeBreakfast:
        return Icons.arrow_upward;
      case ReminderType.afterBreakfast:
        return Icons.arrow_downward;
      case ReminderType.lunch:
        return Icons.restaurant;
      case ReminderType.beforeLunch:
        return Icons.arrow_upward;
      case ReminderType.afterLunch:
        return Icons.arrow_downward;
      case ReminderType.dinner:
        return Icons.dinner_dining;
      case ReminderType.beforeDinner:
        return Icons.arrow_upward;
      case ReminderType.afterDinner:
        return Icons.arrow_downward;
      case ReminderType.bedtime:
        return Icons.nightlight;
      case ReminderType.custom:
        return Icons.schedule;
      case ReminderType.daily:
        return Icons.calendar_today;
      case ReminderType.weekly:
        return Icons.calendar_view_week;
      case ReminderType.monthly:
        return Icons.calendar_view_month;
      default:
        return Icons.question_mark;
    }
  }

  String _getReminderTypeLabel(ReminderType type) {
    switch (type) {
      case ReminderType.wakeUp:
        return 'Wake Up';
      case ReminderType.breakfast:
        return 'Breakfast';
      case ReminderType.beforeBreakfast:
        return 'Before Breakfast';
      case ReminderType.afterBreakfast:
        return 'After Breakfast';
      case ReminderType.lunch:
        return 'Lunch';
      case ReminderType.beforeLunch:
        return 'Before Lunch';
      case ReminderType.afterLunch:
        return 'After Lunch';
      case ReminderType.dinner:
        return 'Dinner';
      case ReminderType.beforeDinner:
        return 'Before Dinner';
      case ReminderType.afterDinner:
        return 'After Dinner';
      case ReminderType.bedtime:
        return 'Bedtime';
      case ReminderType.custom:
        return 'Custom';
      case ReminderType.daily:
        return 'Daily';
      case ReminderType.weekly:
        return 'Weekly';
      case ReminderType.monthly:
        return 'Monthly';
      default:
        return 'Unknown';
    }
  }

  void _addReminderWithRoutineTime(ReminderType type) async {
    controller.updateReminderType(type);

    if (type == ReminderType.custom) {
      final time = await showTimePicker(
        context: Get.context!,
        initialTime: TimeOfDay.now(),
      );
      if (time != null) {
        controller.addReminder(time, type: type);
      }
      return;
    }

    final routine = Get.find<RoutineService>().getRoutine();
    if (routine == null) {
      Get.snackbar(
        'error'.tr,
        'please_set_up_your_daily_routine_first'.tr,
        backgroundColor: Colors.red.withOpacity(0.1),
        colorText: Colors.red,
      );
      return;
    }

    TimeOfDay? routineTime;
    int minutesOffset = 0; // For before/after meal times

    switch (type) {
      case ReminderType.wakeUp:
        final wakeUpTime = routine.wakeUpTime;
        if (wakeUpTime != null) {
          final parts = wakeUpTime.split(':');
          routineTime = TimeOfDay(
            hour: int.parse(parts[0]),
            minute: int.parse(parts[1]),
          );
        }
        break;
      case ReminderType.beforeBreakfast:
        final breakfastTime = routine.breakfastTime;
        if (breakfastTime != null) {
          final parts = breakfastTime.split(':');
          routineTime = TimeOfDay(
            hour: int.parse(parts[0]),
            minute: int.parse(parts[1]),
          );
          minutesOffset = -30; // 30 minutes before breakfast
        }
        break;
      case ReminderType.afterBreakfast:
        final breakfastTime = routine.breakfastTime;
        if (breakfastTime != null) {
          final parts = breakfastTime.split(':');
          routineTime = TimeOfDay(
            hour: int.parse(parts[0]),
            minute: int.parse(parts[1]),
          );
          minutesOffset = 30; // 30 minutes after breakfast
        }
        break;
      case ReminderType.beforeLunch:
        final lunchTime = routine.lunchTime;
        if (lunchTime != null) {
          final parts = lunchTime.split(':');
          routineTime = TimeOfDay(
            hour: int.parse(parts[0]),
            minute: int.parse(parts[1]),
          );
          minutesOffset = -30; // 30 minutes before lunch
        }
        break;
      case ReminderType.afterLunch:
        final lunchTime = routine.lunchTime;
        if (lunchTime != null) {
          final parts = lunchTime.split(':');
          routineTime = TimeOfDay(
            hour: int.parse(parts[0]),
            minute: int.parse(parts[1]),
          );
          minutesOffset = 30; // 30 minutes after lunch
        }
        break;
      case ReminderType.beforeDinner:
        final dinnerTime = routine.dinnerTime;
        if (dinnerTime != null) {
          final parts = dinnerTime.split(':');
          routineTime = TimeOfDay(
            hour: int.parse(parts[0]),
            minute: int.parse(parts[1]),
          );
          minutesOffset = -30; // 30 minutes before dinner
        }
        break;
      case ReminderType.afterDinner:
        final dinnerTime = routine.dinnerTime;
        if (dinnerTime != null) {
          final parts = dinnerTime.split(':');
          routineTime = TimeOfDay(
            hour: int.parse(parts[0]),
            minute: int.parse(parts[1]),
          );
          minutesOffset = 30; // 30 minutes after dinner
        }
        break;
      case ReminderType.bedtime:
        final bedTime = routine.bedTime;
        if (bedTime != null) {
          final parts = bedTime.split(':');
          routineTime = TimeOfDay(
            hour: int.parse(parts[0]),
            minute: int.parse(parts[1]),
          );
          minutesOffset = type == ReminderType.bedtime ? -30 : 0;
        }
        break;
      case ReminderType.custom:
        // Custom time will be selected by user
        break;
      default:
        return;
    }

    if (routineTime != null) {
      // Apply the minutes offset
      if (minutesOffset != 0) {
        final totalMinutes = routineTime.hour * 60 + routineTime.minute + minutesOffset;
        routineTime = TimeOfDay(
          hour: (totalMinutes ~/ 60) % 24,
          minute: totalMinutes % 60,
        );
      }

      controller.addReminder(routineTime, type: type);
    } else {
      Get.snackbar(
        'error'.tr,
        'please_set_up_your_${type.toString().split('.').last.replaceAll(RegExp(r'(?=[A-Z])'), ' ')}_time_in_routine_settings'.tr,
        backgroundColor: Colors.red.withOpacity(0.1),
        colorText: Colors.red,
      );
    }
  }

  String _formatTime(TimeOfDay time, BuildContext context) {
    final now = DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, time.hour, time.minute);
    final format = Get.locale?.languageCode == 'ar' 
        ? intl.DateFormat.jm('ar')
        : intl.DateFormat.jm('en');
    return format.format(dt);
  }

  String _getReminderTypeText(ReminderType type) {
    switch (type) {
      case ReminderType.wakeUp:
        return 'Wake Up';
      case ReminderType.breakfast:
        return 'Breakfast';
      case ReminderType.beforeBreakfast:
        return 'Before Breakfast';
      case ReminderType.afterBreakfast:
        return 'After Breakfast';
      case ReminderType.lunch:
        return 'Lunch';
      case ReminderType.beforeLunch:
        return 'Before Lunch';
      case ReminderType.afterLunch:
        return 'After Lunch';
      case ReminderType.dinner:
        return 'Dinner';
      case ReminderType.beforeDinner:
        return 'Before Dinner';
      case ReminderType.afterDinner:
        return 'After Dinner';
      case ReminderType.bedtime:
        return 'Bedtime';
      case ReminderType.custom:
        return 'Custom';
      case ReminderType.daily:
        return 'Daily';
      case ReminderType.weekly:
        return 'Weekly';
      case ReminderType.monthly:
        return 'Monthly';
      default:
        return 'Unknown';
    }
  }

  Widget _buildSelectedReminders() {
    return Obx(() {
      if (controller.newReminders.isEmpty) {
        return Container(
          padding: const EdgeInsets.symmetric(vertical: 24),
          alignment: Alignment.center,
          child: Column(
            children: [
              Icon(Icons.notifications_none, size: 48, color: Colors.grey.shade400),
              const SizedBox(height: 12),
              Text(
                'no_reminders_set'.tr,
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 16,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'tap_on_a_reminder_type_above_to_set_a_time'.tr,
                style: TextStyle(
                  color: Colors.grey.shade500,
                  fontSize: 14,
                ),
              ),
            ],
          ),
        );
      }

      return Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          children: controller.newReminders.map((reminder) =>
            ListTile(
              leading: Icon(Icons.alarm, color: AppColors.primary),
              title: Text(_getReminderTypeText(reminder.type)),
              subtitle: Text(_formatTime(TimeOfDay(hour: reminder.dateTime.hour, minute: reminder.dateTime.minute), Get.context!)),
              trailing: IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => controller.removeReminder(controller.newReminders.indexOf(reminder)),
                color: Colors.grey.shade600,
              ),
            ),
          ).toList(),
        ),
      );
    });
  }

  Widget _buildSelectedDaysSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('selected_days'.tr, Icons.calendar_today),
        const SizedBox(height: 16),
        Container(
          width: Get.width,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 15,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Obx(() => Text(
                controller.selectedDaysDescription,
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: AppColors.text,
                ),
              )),
              const SizedBox(height: 16),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: [
                  for (int i = 0; i < 7; i++)
                    Obx(() {
                      final bool isSelected = controller.selectedDays[i];
                      return InkWell(
                        onTap: () => controller.toggleDay(i),
                        child: Container(
                          width: 45,
                          height: 45,
                          decoration: BoxDecoration(
                            color: isSelected ? AppColors.primary : Colors.white,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: isSelected ? AppColors.primary : Colors.grey.shade300,
                              width: 1,
                            ),
                          ),
                          child: Center(
                            child: Text(
                              ['monday'.tr, 'tuesday'.tr, 'wednesday'.tr, 'thursday'.tr, 'friday'.tr, 'saturday'.tr, 'sunday'.tr][i],
                              style: GoogleFonts.poppins(
                                fontSize: 16,
                                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                                color: isSelected ? Colors.white : Colors.grey.shade600,
                              ),
                            ),
                          ),
                        ),
                      );
                    }),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  
  Widget _buildRemindersList() {
    return Obx(() {
      if (controller.selectedReminders.isEmpty) {
        return const Center(
          child: Text(
            'No reminders set for this medication',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 16,
            ),
          ),
        );
      }

      return ListView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: controller.selectedReminders.length,
        itemBuilder: (context, index) {
          final reminder = controller.selectedReminders[index];
          return Card(
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: ListTile(
              leading: Container(
                width: 40,
                height: 40,
                // decoration: BoxDecoration(
                //   color: controller.getReminderStatusColor(reminder.status).withOpacity(0.1),
                //   borderRadius: BorderRadius.circular(8),
                // ),
                child: Icon(
                  Icons.alarm,
                  // color: controller.getReminderStatusColor(reminder.statusHistory),
                ),
              ),
              title: Text(
                controller.getFormattedReminderTime(reminder.dateTime),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
              subtitle: Text(
                controller.getReminderStatusText(reminder.getCurrentState()),
                style: TextStyle(
                  color: controller.getReminderStatusColor(reminder.getCurrentState()),
                ),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.edit, color: Colors.blue),
                    onPressed: () {
                      // TODO: Implement edit reminder
                    },
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      // TODO: Implement delete reminder
                    },
                  ),
                ],
              ),
            ),
          );
        },
      );
    });
  }

  Widget _buildFrequencyCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              'How often do you take it?'.tr,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const Divider(height: 1),
          Obx(() => Column(
            children: [
              _buildFrequencyOption('Every day'.tr, 'daily'),
              _buildFrequencyOption('Every other day'.tr, 'alternate'),
              _buildFrequencyOption('Specific days of the week'.tr, 'specific_days'),
              _buildFrequencyOption('On a recurring cycle'.tr, 'recurring'),
              _buildFrequencyOption('Every X days'.tr, 'x_days'),
              _buildFrequencyOption('Every X weeks'.tr, 'x_weeks'),
              _buildFrequencyOption('Every X months'.tr, 'x_months'),
            ],
          )),
        ],
      ),
    );
  }

  Widget _buildFrequencyOption(String title, String value) {
    return RadioListTile<String>(
      title: Text(title),
      value: value,
      groupValue: controller.selectedFrequency.value.toString(),
      onChanged: (value) {
        if (value != null) {
          // If the selected value is the same as current value, deselect it
          if (value == controller.selectedFrequency.value.toString()) {
            controller.selectedFrequency.value = ReminderFrequency.weekly;
          } else {
            // Otherwise select the new value
            controller.updateReminderFrequency(ReminderFrequency.values.firstWhere(
              (e) => e.toString() == value,
              orElse: () => ReminderFrequency.daily,
            ));
          }
        }
      },
      activeColor: AppColors.primary,
      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
    );
  }

  Widget _buildFrequencySelector() {
    final isArabic = Get.locale?.languageCode == 'ar';
    
    return Obx(() => Column(
      crossAxisAlignment: isArabic ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
      children: [
        DropdownButtonFormField<MedicationFrequency>(
          value: controller.selectedMedicationFrequency.value,
          decoration: InputDecoration(
            labelText: 'frequency'.tr,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          ),
          items: MedicationFrequency.values.map((freq) => DropdownMenuItem(
            value: freq,
            child: Text(
              freq.toString().split('.').last.tr,
              textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
              textAlign: isArabic ? TextAlign.right : TextAlign.left,
            ),
          )).toList(),
          onChanged: (value) {
            if (value != null) {
              controller.onFrequencyChanged(value);
            }
          },
        ),
        if (controller.selectedMedicationFrequency.value == MedicationFrequency.custom) ...[
          const SizedBox(height: 16),
          Row(
            textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
            children: [
              Expanded(
                child: TextFormField(
                  controller: controller.customDaysController,
                  keyboardType: TextInputType.number,
                  textDirection: TextDirection.ltr, // Keep numbers LTR
                  textAlign: isArabic ? TextAlign.right : TextAlign.left,
                  decoration: InputDecoration(
                    labelText: 'number_of_days'.tr,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    hintText: 'enter_days'.tr,
                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please_enter_days'.tr;
                    }
                    final days = int.tryParse(value);
                    if (days == null || days <= 0) {
                      return 'invalid_days'.tr;
                    }
                    return null;
                  },
                ),
              ),
              const SizedBox(width: 16),
              Text(
                'days'.tr,
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  color: Colors.grey.shade800,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            'select_days'.tr,
            style: GoogleFonts.poppins(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.grey.shade800,
            ),
            textAlign: isArabic ? TextAlign.right : TextAlign.left,
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey.shade50,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: Wrap(
              spacing: 8,
              runSpacing: 12,
              textDirection: isArabic ? TextDirection.rtl : TextDirection.ltr,
              children: List.generate(7, (index) {
                // Adjust index for Arabic to show days from right to left
                final adjustedIndex = isArabic ? (6 - index) : index;
                final dayName = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][adjustedIndex];
                return Obx(() {
                  final bool isSelected = controller.selectedDays[adjustedIndex];
                  return InkWell(
                    onTap: () => controller.toggleDay(adjustedIndex),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 45,
                      height: 45,
                      decoration: BoxDecoration(
                        color: isSelected ? AppColors.primary : Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: isSelected ? AppColors.primary : Colors.grey.shade300,
                          width: 1.5,
                        ),
                        boxShadow: isSelected ? [
                          BoxShadow(
                            color: AppColors.primary.withOpacity(0.3),
                            blurRadius: 8,
                            offset: const Offset(0, 2),
                          ),
                        ] : null,
                      ),
                      child: Center(
                        child: Text(
                          dayName.tr,
                          style: GoogleFonts.poppins(
                            color: isSelected ? Colors.white : Colors.grey.shade800,
                            fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                    ),
                  );
                });
              }),
            ),
          ),
        ],
      ],
    ));
  }

  Widget _buildPrescriptionSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('prescription'.tr, Icons.medical_information),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 15,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'has_prescription'.tr,
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: AppColors.text,
                    ),
                  ),
                  Obx(() => Switch(
                    value: controller.hasPrescription.value,
                    onChanged: (value) => controller.hasPrescription.value = value,
                    activeColor: AppColors.primary,
                  )),
                ],
              ),
              Obx(() {
                if (!controller.hasPrescription.value) return SizedBox.shrink();
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 16),
                    _buildInputContainer(
                      child: TextFormField(
                        controller: controller.prescriptionDetailsController,
                        maxLines: 3,
                        textDirection: Get.locale?.languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr,
                        textAlign: Get.locale?.languageCode == 'ar' ? TextAlign.right : TextAlign.left,
                        decoration: _buildInputDecoration(
                          'prescription_details'.tr,
                          Icons.description_outlined,
                        ).copyWith(
                          alignLabelWithHint: true,
                          hintTextDirection: Get.locale?.languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    InkWell(
                      onTap: controller.pickPrescriptionImage,
                      child: Container(
                        width: double.infinity,
                        height: 200,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          color: Colors.grey.shade100,
                          border: Border.all(
                            color: Colors.grey.shade300,
                            width: 1,
                          ),
                        ),
                        child: Obx(() {
                          if (controller.prescriptionImageRx.value != null) {
                            return Stack(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: Image.memory(
                                    base64Decode(controller.prescriptionImageRx.value!),
                                    width: double.infinity,
                                    height: 200,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) =>
                                        _buildImageError(),
                                  ),
                                ),
                                Positioned(
                                  top: 8,
                                  right: Get.locale?.languageCode == 'ar' ? null : 8,
                                  left: Get.locale?.languageCode == 'ar' ? 8 : null,
                                  child: IconButton(
                                    onPressed: () {
                                      controller.medication.update((med) {
                                        med!.prescriptionImage = '';
                                      });
                                    },
                                    icon: const Icon(Icons.close),
                                    color: Colors.red,
                                    style: IconButton.styleFrom(
                                      backgroundColor: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            );
                          }
                          return Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.add_photo_alternate_outlined,
                                  size: 48,
                                  color: Colors.grey.shade400,
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  'add_prescription_image'.tr,
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    color: Colors.grey.shade600,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }),
                      ),
                    ),
                  ],
                );
              }),
            ],
          ),
        ),
      ],
    );
  }


  Widget _buildSectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(
          icon,
          size: 24,
          color: AppColors.primary,
        ),
        const SizedBox(width: 10),
        Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 18,
            fontWeight: FontWeight.w600,
            color: AppColors.text,
          ),
        ),
      ],
    );
  }

  Widget _buildInputContainer({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.symmetric(horizontal: 5),
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Padding(
        padding: padding,
        child: child,
      ),
    );
  }

  InputDecoration _buildInputDecoration(String hint, IconData icon) {
    return InputDecoration(
      hintText: hint,
      hintStyle: GoogleFonts.poppins(
        color: Colors.grey.shade400,
        fontSize: 16,
      ),
      prefixIcon: Icon(
        icon,
        color: AppColors.primary,
        size: 24,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(15),
        borderSide: BorderSide.none,
      ),
      filled: true,
      fillColor: Colors.white,
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 16,
      ),
    );
  }

  Widget _buildImageError() {
    return Container(
      width: double.infinity,
      height: 200,
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Center(
        child: Icon(Icons.error_outline, color: Colors.red, size: 40),
      ),
    );
  }

  Widget _buildInteractionsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionTitle('interactions'.tr, Icons.warning_amber_rounded),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 15,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Obx(() {
            final interactions = controller.interactions;
            if (interactions.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.check_circle_outline,
                      size: 48,
                      color: Colors.grey.shade400,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'no_interactions'.tr,
                      textAlign: TextAlign.center,
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              );
            }

            final interactionService = Get.find<InteractionService>();
            final schedule = interactionService.findOptimalSchedule(
              [controller.toMedication(), ...controller.existingMedications],
            );

            return Column(
              children: interactions.map((interaction) =>
                _buildInteractionItem(interaction, schedule)
              ).toList(),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildInteractionItem(InteractionModel interaction, Map<String, List<DateTime>> schedule) {
    final recommendedTimes = schedule[interaction.medicationName] ?? [];
    
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.warning_rounded,
                  color: interaction.riskLevel.color,
                  size: 24,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    interaction.medicationName,
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: interaction.riskLevel.color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    interaction.riskLevel.displayName,
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: interaction.riskLevel.color,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              interaction.description,
              style: GoogleFonts.poppins(fontSize: 14),
            ),
            if (recommendedTimes.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                'recommended_times'.tr,
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              Wrap(
                spacing: 8,
                children: recommendedTimes.map((time) => 
                  Chip(
                    label: Text(
                      intl.DateFormat('hh:mm a').format(time),
                      style: GoogleFonts.poppins(fontSize: 12),
                    ),
                    backgroundColor: AppColors.primary.withOpacity(0.1),
                  ),
                ).toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}