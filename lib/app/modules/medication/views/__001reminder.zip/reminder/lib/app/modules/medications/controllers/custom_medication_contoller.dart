import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:meta/meta.dart';
import 'package:reminder/app/data/usecases/medication/add_medication_usecase.dart';
import 'package:reminder/app/data/usecases/medication/delete_medication_usecase.dart';
import 'package:reminder/app/data/usecases/medication/get_all_medications_usecase.dart';
import 'package:reminder/app/data/usecases/medication/update_medication_usecase.dart';
import 'package:reminder/app/data/models/medication_model.dart';

import '../../../data/models/reminder_model.dart';

class CustomMedicationController extends GetxController {
  final AddMedicationUseCase _addMedicationUseCase;
  final UpdateMedicationUseCase _updateMedicationUseCase;
  final DeleteMedicationUseCase _deleteMedicationUseCase;
  final GetAllMedicationsUseCase _getAllMedicationsUseCase;
  final GetMedicationUseCase _getMedicationUseCase;

  CustomMedicationController({
    required AddMedicationUseCase addMedicationUseCase,
    required GetMedicationUseCase getMedicationUseCase,
    required UpdateMedicationUseCase updateMedicationUseCase,
    required DeleteMedicationUseCase deleteMedicationUseCase,
    required GetAllMedicationsUseCase getAllMedicationsUseCase,
  })  : _addMedicationUseCase = addMedicationUseCase,
        _updateMedicationUseCase = updateMedicationUseCase,
        _getMedicationUseCase=getMedicationUseCase,
        _deleteMedicationUseCase = deleteMedicationUseCase,
        _getAllMedicationsUseCase = getAllMedicationsUseCase;

  final RxBool isLoading = false.obs;
  final RxList<MedicationModel> medications = <MedicationModel>[].obs;
  final Rx<String?> errorMessage = Rx<String?>(null);
  Rx<MedicationModel?> selectedMedication = Rx<MedicationModel?>(null);

  final nameController = TextEditingController();
  final instructionsController = TextEditingController();
  final dosageController = TextEditingController();
  final frequencyController = TextEditingController();
  final quantityController = TextEditingController();
  final remainingQuantityController = TextEditingController();
  final startDateController = TextEditingController();
  final endDateController = TextEditingController();

  final RxList<ReminderModel>  reminders = RxList.empty();

  RxInt get currentTab => 0.obs;

  get formKey => null;
  @override
  void onInit() {
    super.onInit();
    getAllMedications();
  }

  Future<void> getAllMedications() async {
    _loadingWrapper(() async {
      final result = await _getAllMedicationsUseCase();
      medications.assignAll(result);
    }, 'Failed to get medications');
  }

  Future<void> addMedication(MedicationModel medication) async {
    await _loadingWrapper(() async {
      await _addMedicationUseCase(medication);
      await getAllMedications();
      _showSuccessDialog('Medication added successfully');
    }, 'Failed to add medication');
  }

  Future<void> updateMedication(MedicationModel medication) async {
    await _loadingWrapper(() async {
      await _updateMedicationUseCase(medication);
      await getAllMedications();
      _showSuccessDialog('Medication updated successfully');
    }, 'Failed to update medication');
  }

  Future<void> deleteMedication(MedicationModel medication) async {
    await _loadingWrapper(() async {
      await _deleteMedicationUseCase(medication);
      await getAllMedications();
      _showSuccessDialog('Medication deleted successfully');
    }, 'Failed to delete medication');
  }

  Future<void> _loadingWrapper(Future<void> Function() action, String errorMsg) async {
    try {
      isLoading.value = true;
      errorMessage.value = null;
      await action();
    } catch (e) {
      errorMessage.value = '$errorMsg: $e';
      _showErrorDialog(errorMessage.value!);
    } finally {
      isLoading.value = false;
    }
  }

  void _showSuccessDialog(String message) {
    Get.snackbar(
      'Success',
      message,
      snackPosition: SnackPosition.BOTTOM,
      duration: Duration(seconds: 3),
    );
  }

  void _showErrorDialog(String message) {
    Get.snackbar(
      'Error',
      message,
      snackPosition: SnackPosition.BOTTOM,
      duration: Duration(seconds: 3),
      backgroundColor: Get.theme.primaryColor,
      colorText: Get.theme.colorScheme.onError,
    );
  }

  void addReminder(ReminderModel reminder) {
    reminders.add(reminder);
  }
  void removeReminder(ReminderModel reminder) {
    reminders.remove(reminder);
  }
}