enum ReminderState {
  taken,
  missed,
  skipped,
  pending,
}
