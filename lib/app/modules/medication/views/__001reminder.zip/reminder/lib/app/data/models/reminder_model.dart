import 'package:logger/logger.dart';
import 'reminder_status.dart';
import 'reminder_state.dart';

enum ReminderType {
  wakeUp,
  breakfast,
  beforeBreakfast,
  afterBreakfast,
  lunch,
  beforeLunch,
  afterLunch,
  dinner,
  beforeDinner,
  afterDinner,
  bedtime,
  custom,
  daily,
  weekly,
  monthly,
}

enum ReminderFrequency {
  none,
  daily,
  weekly,
  monthly,
  custom,
}

class ReminderModel {
  final String id;
  final String? medicationId;
  final String? medicationName;
  DateTime dateTime;
  final ReminderType type;
  List<ReminderStatus> statusHistory;

  ReminderModel({
    required this.id,
    this.medicationId,
    this.medicationName,
    required this.dateTime,
    required this.type,
    List<ReminderStatus>? statusHistory,
  }) : statusHistory = statusHistory ?? [ReminderStatus(
    timestamp: DateTime.now(),
    state: ReminderState.pending,
  )];

  ReminderState getCurrentState() {
    if (statusHistory.isEmpty) return ReminderState.pending;
    return statusHistory.last.state;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'medicationId': medicationId,
      'medicationName': medicationName,
      'dateTime': dateTime.toIso8601String(),
      'type': type.toString(),
      'statusHistory': statusHistory.map((status) => status.toJson()).toList(),
    };
  }

  factory ReminderModel.fromJson(Map<String, dynamic> json) {
    return ReminderModel(
      id: json['id'],
      medicationId: json['medicationId'],
      medicationName: json['medicationName'],
      dateTime: DateTime.parse(json['dateTime']),
      type: ReminderType.values.firstWhere(
        (e) => e.toString() == json['type'],
        orElse: () => ReminderType.custom,
      ),
      statusHistory: (json['statusHistory'] as List?)
          ?.map((status) => ReminderStatus.fromJson(status))
          .toList() ?? [],
    );
  }

  ReminderModel copyWith({
    String? id,
    String? medicationId,
    String? medicationName,
    DateTime? dateTime,
    ReminderType? type,
    List<ReminderStatus>? statusHistory,
  }) {
    return ReminderModel(
      id: id ?? this.id,
      medicationId: medicationId ?? this.medicationId,
      medicationName: medicationName ?? this.medicationName,
      dateTime: dateTime ?? this.dateTime,
      type: type ?? this.type,
      statusHistory: statusHistory ?? List.from(this.statusHistory),
    );
  }

  ReminderState getStateForDate(DateTime date) {
    final statusForDate = statusHistory
        .where((status) => _isSameDay(status.timestamp, date))
        .toList();

    if (statusForDate.isEmpty) {
      if (date.isBefore(DateTime.now())) {
        return ReminderState.missed;
      }
      return ReminderState.pending;
    }

    return statusForDate.last.state;
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }
}
