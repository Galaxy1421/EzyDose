import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:logger/logger.dart';
import 'package:reminder/app/data/models/reminder_model.dart';
import 'package:reminder/app/data/usecases/medication/get_all_medications_usecase.dart';
import 'package:reminder/app/modules/medication/views/edit_medication_view.dart';
import 'package:reminder/app/modules/medications/controllers/custom_medication_contoller.dart';
import '../../../data/models/medication_model.dart';
import '../../../data/models/reminder_state.dart';
import '../../../data/services/medication_service.dart';
import '../../../data/usecases/reminder/update_reminder_usecase.dart';
import '../../../routes/app_pages.dart';
import '../../dashboard/controllers/custom_reminder_controller.dart';

class MedicationsController extends GetxController {
  final MedicationService _medicationService = Get.find();
  final medications = <MedicationModel>[].obs;
  final isLoading = false.obs;
  final logger = Logger();
  final CustomReminderController _reminderController = Get.find();
  final GetMedicationUseCase _getMedicationUseCase = Get.find();
  @override
  void onInit() {
    super.onInit();
    loadMedications();
    ever(_medicationService.medications, (_) => loadMedications());
  }
  Future<int> calculateTakenReminders(String medicationId) async{
    MedicationModel? medicationModel = await _getMedicationUseCase(medicationId);
    int does = medicationModel!.doseQuantity;
    int count = 0;
    final reminders = await _reminderController.getRemindersByMedicationId(medicationId);
   for(var reminder in reminders){
     for(var state in reminder.statusHistory){
       if(state.state == ReminderState.taken){
         count = count + does;
       }
     }
   }
   return count;
  }

  Future<void> loadMedications() async {
    try {
      isLoading.value = true;
      await _medicationService.loadMedications();
      medications.value = _medicationService.medications.toList()
        ..sort((a, b) => (b.expiryDate ?? DateTime.now())
            .compareTo(a.expiryDate ?? DateTime.now()));
    } catch (e) {
      logger.e('Error loading medications: $e');
      Get.snackbar(
        'Error',
        'Failed to load medications: $e',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isLoading.value = false;
    }
  }

  String formatDate(DateTime? date) {
    if (date == null) return 'No date set';
    return DateFormat('MMM dd, yyyy').format(date);
  }

  String formatTime(DateTime time) {
    return DateFormat('hh:mm a').format(time);
  }

  bool isExpired(DateTime? expirationDate) {
    if (expirationDate == null) return false;
    final now = DateTime.now();
    return expirationDate.isBefore(now);
  }

  void showMedicationOptions(MedicationModel medication) {
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(16),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.edit),
              title:  Text('edit_medication'.tr),
              onTap: () {
                Get.back();
                editMedication(medication);
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete, color: Colors.red),
              title: const Text('Delete Medication', style: TextStyle(color: Colors.red)),
              onTap: () {
                Get.dialog(
                  AlertDialog(
                    title: const Text('Delete Medication'),
                    content: Text('Are you sure you want to delete ${medication.name} ?'),
                    actions: [
                      TextButton(
                        onPressed: () => Get.back(),
                        child:  Text('cancel'.tr),
                      ),
                      TextButton(
                        onPressed: () {
                          Get.find<CustomMedicationController>().deleteMedication(medication);

                          Get.find<DeleteMedicationRemindersUseCase>().call(medication.id);
                          Get.back();
                        },
                        child:  Text('delete'.tr, style: TextStyle(color: Colors.red)),
                      ),
                    ],
                  ),
                );

              },
            ),
          ],
        ),
      ),
    );
  }

  void editMedication(MedicationModel medication) {
    Get.to(EditMedicationView(medication: medication));
  }

  void _showDeleteConfirmation(MedicationModel medication) {
    Get.dialog(
      AlertDialog(
        title: const Text('Delete Medication'),
        content: Text('Are you sure you want to delete ${medication.name} ${medication.id}?'),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {

              _deleteMedication(medication);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteMedication(MedicationModel medication) async {
    try {
      await _medicationService.deleteMedication(medication.id);
      Get.snackbar(
        'Success',
        'Medication deleted successfully',
        backgroundColor: Colors.green.withOpacity(0.1),
        colorText: Colors.green,
        snackPosition: SnackPosition.BOTTOM,
      );
      await loadMedications();
    } catch (e) {
      logger.e('Error deleting medication: $e');
      Get.snackbar(
        'Error',
        'Failed to delete medication: $e',
        backgroundColor: Colors.red.withOpacity(0.1),
        colorText: Colors.red,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }
}
