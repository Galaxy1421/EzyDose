import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:logger/logger.dart';
import 'package:lottie/lottie.dart';
import 'package:reminder/app/modules/dashboard/controllers/custom_reminder_controller.dart';
import 'package:reminder/app/modules/medications/controllers/custom_medication_contoller.dart';
import 'package:reminder/app/routes/app_pages.dart';
import 'package:uuid/uuid.dart';

import '../../../core/theme/app_colors.dart';
import '../../../data/models/interaction_model.dart';
import '../../../data/models/medication_model.dart';
import '../../../data/models/reminder_model.dart';
import '../../../data/models/reminder_state.dart';
import '../../../data/models/reminder_status.dart';
import '../../../data/sample/sample_data.dart';
import '../../../data/services/interaction_service.dart';
import '../../../data/services/medication_service.dart';
import '../../../data/services/routine_service.dart';
import '../../../data/services/settings_service.dart';
import '../../../services/custom_interaction_service.dart';
import '../../../services/custom_schulder_service.dart';

class AddMedicationController extends GetxController {
  final _logger = Logger();
  final _medicationService = Get.find<MedicationService>();
  final _uuid = const Uuid();
  final _settingsService = Get.find<SettingsService>();
  final _interactionService = Get.find<InteractionService>();
  final _scheduleService = Get.find<ScheduleService>();

  final formKey = GlobalKey<FormState>();
  final CustomInteractionService _customInteractionService = Get.find();
  // Controllers
  final nameController = TextEditingController();
  final instructionsController = TextEditingController();
  final doseQuantityController = TextEditingController();
  final totalQuantityController = TextEditingController();
  final unitController = TextEditingController();
  final prescriptionDetailsController = TextEditingController();
  final customDaysController = TextEditingController();

  // Observable values
  final currentTab = 0.obs;
  final medicationId = RxString('');
  final selectedMedicationFrequency = MedicationFrequency.daily.obs;
  final selectedDays = RxList<bool>.filled(7, false);  // Sunday to Saturday
  final hasPrescription = false.obs;
  final prescriptionImageRx = RxString('');
  final medicationImageRx = RxString('');
  final selectedExpiryDate = Rx<DateTime?>(null);
  final newReminders = <ReminderModel>[].obs;
  final interactions = <InteractionModel>[].obs;
  final selectedUnit = 'pills'.obs;
  final reminders = <ReminderModel>[].obs;
  final selectedReminderType = ReminderType.custom.obs;
  final searchResults = <MedicationModel>[].obs;
  final selectedMedication = Rx<MedicationModel?>(null);
  final selectedMedicationImage = Rx<String?>(null);
  final existingMedications = <MedicationModel>[].obs;
  final isLoading = false.obs;
  final expiryDate = Rx<DateTime?>(null);
  final selectedStartDate = Rx<DateTime?>(null);
  final selectedEndDate = Rx<DateTime?>(null);
  final notificationsEnabled = true.obs;
  final selectedTime = Rx<TimeOfDay>(TimeOfDay.now());
  final medication = Rx<MedicationModel>(MedicationModel(
    id: '',
    name: '',
    totalQuantity: 0,
    doseQuantity: 1,
    unit: 'pills',
    interactions: [],
    prescriptionText: '',
    hasPrescription: false,
    imageUrl: '',
    prescriptionImage: '',
    instructions: '',
  ));
  final medicationToEdit = Rx<MedicationModel?>(null);
  final isEditing = false.obs;

  // Additional properties
  final selectedFrequency = ReminderFrequency.daily.obs;
  final selectedReminders = <ReminderModel>[].obs;

  // Observable values for expiry and quantity reminders
  final selectedExpiryReminderDays = 7.obs;
  final selectedQuantityReminderDays = 7.obs;

  // List of available days options
  final expiryReminderOptions = [3, 7, 14, 30];
  final quantityReminderOptions = [3, 7, 14, 30];

  final isGeneratingReminders = false.obs;

  String _generateId() => _uuid.v4();

  final CustomReminderController _customReminderController = Get.find();
  final CustomMedicationController _customMedicationController = Get.find();
  @override
  void onInit() {
    super.onInit();
    _initializeControllers();
    customDaysController.text = '1'; // Default value
    // _loadExistingMedications();

    // Set default unit
    if (medication.value.unit.isEmpty) {
      medication.value.unit = 'tablets';
    }

    if (Get.arguments != null) {
      final med = Get.arguments as MedicationModel;
      medicationToEdit.value = med;
      isEditing.value = true;
      loadMedication(med);
    }

    // Listen to medication name changes to set default reminders
    nameController.addListener(_updateDefaultReminders);
  }

  void _initializeControllers() {
    nameController.addListener(_updateMedicationName);
    doseQuantityController.addListener(_updateDoseQuantity);
    instructionsController.addListener(_updateInstructions);
    prescriptionDetailsController.addListener(_updatePrescription);
  }

  void _updateMedicationName() {
    medication.update((val) {
      if (val != null) {
        val.name = nameController.text;
      }
    });
  }

  void _updateDoseQuantity() {
    medication.update((val) {
      if (val != null) {
        val.doseQuantity = int.tryParse(doseQuantityController.text) ?? 1;
      }
    });
  }

  void _updateInstructions() {
    medication.update((val) {
      if (val != null) {
        val.instructions = instructionsController.text;
      }
    });
  }

  void _updatePrescription() {
    medication.update((val) {
      if (val != null) {
        val.prescriptionText = prescriptionDetailsController.text;
        val.hasPrescription = prescriptionDetailsController.text.isNotEmpty || (prescriptionImageRx.value.isNotEmpty);
      }
    });
  }

  void _updateDefaultReminders() {
    final medicationName = nameController.text.toLowerCase();

    // Only set default reminders if there are no existing reminders
    if (reminders.isEmpty) {
      switch (medicationName) {
        case String name when name.contains('lisinopril'):
        // addReminder(
        //   const TimeOfDay(hour: 8, minute: 0),
        //   type: ReminderType.beforeBreakfast,
        // );
          instructionsController.text = 'take_10mg_once_daily_on_an_empty_stomach_at_least_1_hour_before_meals_take_with_a_full_glass_of_water_avoid_salt_substitutes_containing_potassium'.tr;
          selectedUnit.value = 'tablets'.tr;
          break;

        case String name when name.contains('metformin'):
        // addReminder(
        //   const TimeOfDay(hour: 8, minute: 30),
        //   type: ReminderType.afterBreakfast,
        // );
        // addReminder(
        //   const TimeOfDay(hour: 18, minute: 30),
        //   type: ReminderType.afterDinner,
        // );
          instructionsController.text = 'take_500mg_twice_daily_with_meals_to_minimize_stomach_upset_take_with_food_to_reduce_gastrointestinal_side_effects_stay_well_hydrated_throughout_the_day'.tr;
          selectedUnit.value = 'tablets'.tr;
          break;
      }
    }
  }

  void loadMedication(MedicationModel med) {
    // Update text controllers (this will trigger their respective listeners)
    nameController.text = med.name;
    instructionsController.text = med.instructions ?? '';
    doseQuantityController.text = med.doseQuantity.toString();
    prescriptionDetailsController.text = med.prescriptionText ?? '';

    // Update medication model fields
    medication.update((val) {
      if (val != null) {
        val.id = med.id;
        val.name = med.name;
        val.instructions = med.instructions ?? '';
        val.doseQuantity = med.doseQuantity;
        val.unit = med.unit;
        val.prescriptionText = med.prescriptionText;
        val.prescriptionImage = med.prescriptionImage ?? '';
        val.imageUrl = med.imageUrl ?? '';
        val.hasPrescription = med.hasPrescription;
        val.interactions = List.from(med.interactions);
      }
    });
  }

  void loadMedicationForEdit(MedicationModel med) {
    nameController.text = med.name;
    instructionsController.text = med.instructions;
    totalQuantityController.text = med.totalQuantity.toString();
    doseQuantityController.text = med.doseQuantity.toString();
    unitController.text = med.unit;
    expiryDate.value = med.expiryDate;
    if (med.expiryDate != null) {
      expiryDateController.text = med.expiryDate.toString();
    }
    selectedImage.value = med.imageUrl;
    selectedPrescriptionImage.value = med.prescriptionImage;
    interactions.assignAll(med.interactions);
    medicationToEdit.value = med;
  }

  void resetMedication() {
    medication.value = MedicationModel(
      name: '',
      instructions: '',
      doseQuantity: 1,
      totalQuantity: 0,
      unit: 'pills',
      hasPrescription: false, id: '',
    );

    // Reset controllers
    nameController.clear();
    doseQuantityController.clear();
    instructionsController.clear();
    prescriptionDetailsController.clear();
    // quantityController.clear();

    // Reset other values
    // selectedFrequency.value = ReminderFrequency.daily;
    selectedReminderType.value = ReminderType.custom;
    selectedTime.value = TimeOfDay.now();
    selectedDays.value = List.filled(7, false);
    prescriptionImageRx.value = '';
    medicationImageRx.value = '';
  }

  @override
  void onClose() {
    nameController.removeListener(_updateDefaultReminders);
    nameController.removeListener(_updateMedicationName);
    doseQuantityController.removeListener(_updateDoseQuantity);
    instructionsController.removeListener(_updateInstructions);
    prescriptionDetailsController.removeListener(_updatePrescription);

    nameController.dispose();
    doseQuantityController.dispose();
    instructionsController.dispose();
    prescriptionDetailsController.dispose();
    customDaysController.dispose();

    // medication.reset();
    // selectedReminderTypes.clear();
    super.onClose();
  }

  Future<void> addReminder(TimeOfDay time, {ReminderType type = ReminderType.custom}) async {
    try {
      // Only check for duplicates on non-custom reminders
      if (type != ReminderType.custom && reminders.any((r) => r.type == type)) {
        Get.snackbar(
          'Warning',
          'A reminder for ${_getReminderTypeText(type)} already exists',
          backgroundColor: Colors.orange.withOpacity(0.1),
          colorText: Colors.orange[800],
        );
        return;
      }

      // Get time from settings service for predefined types
      TimeOfDay reminderTime = time;
      if (type != ReminderType.custom) {
        String timeStr;
        switch (type) {
          case ReminderType.wakeUp:
            timeStr = _settingsService.wakeUpTime;
            break;
          case ReminderType.beforeBreakfast:
            timeStr = _settingsService.beforeBreakfastTime;
            break;
          case ReminderType.afterBreakfast:
            timeStr = _settingsService.afterBreakfastTime;
            break;
          case ReminderType.beforeLunch:
            timeStr = _settingsService.beforeLunchTime;
            break;
          case ReminderType.afterLunch:
            timeStr = _settingsService.afterLunchTime;
            break;
          case ReminderType.beforeDinner:
            timeStr = _settingsService.beforeDinnerTime;
            break;
          case ReminderType.afterDinner:
            timeStr = _settingsService.afterDinnerTime;
            break;
          case ReminderType.bedtime:
            timeStr = _settingsService.bedTime;
            break;
          default:
            timeStr = '';
        }

        if (timeStr.isNotEmpty) {
          final parts = timeStr.split(':');
          if (parts.length == 2) {
            reminderTime = TimeOfDay(
              hour: int.parse(parts[0]),
              minute: int.parse(parts[1]),
            );
          }
        }
      }

      final reminder = ReminderModel(
        id: _generateId(),
        medicationId: medicationId.value,
        medicationName: medication.value.name,
        dateTime: DateTime(
          DateTime.now().year,
          DateTime.now().month,
          DateTime.now().day,
          reminderTime.hour,
          reminderTime.minute,
        ),
        type: type,
        statusHistory: [
          ReminderStatus(
            timestamp: DateTime.now(),
            state: ReminderState.pending,
          ),
        ],
      );

      reminders.add(reminder);
      update();
    } catch (e) {
      _logger.e('Error adding reminder', error: e);
      Get.snackbar(
        'Error',
        'Failed to create reminder',
        backgroundColor: Colors.red.withOpacity(0.1),
        colorText: Colors.red[800],
      );
    }
  }

  String _getReminderTypeText(ReminderType type) {
    switch (type) {
      case ReminderType.wakeUp:
        return 'Wake Up';
      case ReminderType.beforeBreakfast:
        return 'Before Breakfast';
      case ReminderType.afterBreakfast:
        return 'After Breakfast';
      case ReminderType.beforeLunch:
        return 'Before Lunch';
      case ReminderType.afterLunch:
        return 'After Lunch';
      case ReminderType.beforeDinner:
        return 'Before Dinner';
      case ReminderType.afterDinner:
        return 'After Dinner';
      case ReminderType.bedtime:
        return 'Bedtime';
      default:
        return type.toString().split('.').last;
    }
  }

  void removeReminder(int index) {
    if (index >= 0 && index < reminders.length) {
      reminders.removeAt(index);
      update();
    }
  }

  Future<void> onSavePressed() async {
    if (!_validateForm()) return;

    try {
      // Generate new medication ID if not exists
      if (medicationId.value.isEmpty) {
        medicationId.value = _generateId();
      }

      // Create medication model
      final medication = MedicationModel(
        id: medicationId.value,
        name: nameController.text,
        instructions: instructionsController.text,
        totalQuantity: int.tryParse(totalQuantityController.text) ?? 0,
        doseQuantity: int.tryParse(doseQuantityController.text) ?? 1,
        unit: selectedUnit.value,
        expiryDate: expiryDate.value,
        hasPrescription: hasPrescription.value,
        prescriptionText: prescriptionDetailsController.text,
        prescriptionImage: prescriptionImageRx.value,
        imageUrl: medicationImageRx.value,
        frequency: selectedMedicationFrequency.value,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      medication.interactions = interactions.value;
      Logger().d('Checking interactions for medication: ${medication.name}');
      Logger().d('Number of interactions: ${medication.interactions.length}');
      
      InteractionResult result = await _customInteractionService.checkInteraction(medication, reminders);
      Logger().d('Interaction check result:');
      Logger().d('Has interaction: ${result.hasInteraction}');
      Logger().d('Number of conflicts: ${result.conflicts.length}');
      Logger().d('Message: ${result.message}');
      
      if (result.conflicts.isNotEmpty) {
        Logger().d('Showing interaction dialog');
        final shouldContinue = await _showInteractionDialog(result);
        Logger().d('Dialog result: $shouldContinue');
        if (!shouldContinue) return;
      }

      _customMedicationController.addMedication(medication);
      
      // Schedule reminders with notifications and torch
      for (final reminder in reminders) {
        _customReminderController.addReminder(reminder);
        
        // Schedule notification with torch for each reminder time
        await _scheduleService.scheduleReminder(
          reminder,
          'Time for ${medication.name}',
          'Take ${medication.doseQuantity} ${medication.unit} of ${medication.name}\n${medication.instructions}',
          useTorch: true, // Enable torch for all reminders
        );
      }

      Get.offAllNamed(Routes.HOME);
      Get.snackbar(
        'Success',
        'Medication and reminders saved successfully',
        backgroundColor: Colors.green,
        colorText: Colors.white,
        duration: const Duration(seconds: 1)
      );

    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to save medication: ${e.toString()}',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }

  Future<bool> _showInteractionDialog(InteractionResult result) async {
    final conflicts = result.conflicts.toList();
    final RxList<ConflictDetail> rxConflicts = conflicts.obs;

    return await Get.dialog<bool>(
      AlertDialog(
        title: Text(
          'medication_interaction_warning'.tr,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: AppColors.primary,
          ),
        ),
        content: Obx(() => SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'medication_interaction_description'.tr,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 16),
              ...rxConflicts.map((conflict) {
                final existingTime = conflict.existingReminder.dateTime;
                final newTime = conflict.newReminder.dateTime;
                final timeDiff = newTime.difference(existingTime).inMinutes.abs();
                
                return Container(
                  margin: const EdgeInsets.only(bottom: 16),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppColors.primary.withOpacity(0.3),
                      width: 1,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(
                            Icons.warning_rounded,
                            color: Colors.orange[700],
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              conflict.existingMedication.name,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            _buildTimeRow(
                              'existing_reminder'.tr,
                              existingTime,
                              AppColors.primary,
                            ),
                            const SizedBox(height: 8),
                            _buildTimeRow(
                              'new_reminder'.tr,
                              newTime,
                              Colors.orange[700]!,
                            ),
                            const Divider(height: 16),
                            Text(
                              'time_difference'.tr + ': ' + 
                              (timeDiff == 0 
                                ? 'same_time'.tr 
                                : '$timeDiff ' + 'minutes'.tr),
                              style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          _buildTimeButton(
                            onPressed: () {
                              final index = rxConflicts.indexOf(conflict);
                              final adjustedTime = conflict.newReminder.dateTime.subtract(const Duration(minutes: 30));
                              final adjustedReminder = conflict.newReminder.copyWith(dateTime: adjustedTime);
                              final adjustedConflict = conflict.copyWith(newReminder: adjustedReminder);
                              rxConflicts[index] = adjustedConflict;
                              
                              // Update the actual reminder
                              final reminderIndex = reminders.indexWhere((r) => r.id == conflict.newReminder.id);
                              if (reminderIndex != -1) {
                                reminders[reminderIndex] = adjustedReminder;
                              }
                            },
                            icon: Icons.remove,
                            label: 'subtract_30_minutes'.tr,
                          ),
                          const SizedBox(width: 8),
                          _buildTimeButton(
                            onPressed: () {
                              final index = rxConflicts.indexOf(conflict);
                              final adjustedTime = conflict.newReminder.dateTime.add(const Duration(minutes: 30));
                              final adjustedReminder = conflict.newReminder.copyWith(dateTime: adjustedTime);
                              final adjustedConflict = conflict.copyWith(newReminder: adjustedReminder);
                              rxConflicts[index] = adjustedConflict;
                              
                              // Update the actual reminder
                              final reminderIndex = reminders.indexWhere((r) => r.id == conflict.newReminder.id);
                              if (reminderIndex != -1) {
                                reminders[reminderIndex] = adjustedReminder;
                              }
                            },
                            icon: Icons.add,
                            label: 'add_30_minutes'.tr,
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              }).toList(),
            ],
          ),
        )),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: Text(
              'edit_reminders'.tr,
              style: const TextStyle(color: Colors.grey),
            ),
          ),
          ElevatedButton(
            onPressed: () => Get.back(result: true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: Text(
              'save_anyway'.tr,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
      barrierDismissible: false,
    ) ?? false;
  }

  Widget _buildTimeRow(String label, DateTime time, Color color) {
    final timeStr = Get.locale?.languageCode == 'ar'
        ? '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}'
        : '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    
    return Row(
      children: [
        Text(
          '$label: ',
          style: TextStyle(
            color: Colors.grey[600],
            fontSize: 14,
          ),
        ),
        Text(
          timeStr,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ],
    );
  }

  Widget _buildTimeButton({
    required VoidCallback onPressed,
    required IconData icon,
    required String label,
  }) {
    return TextButton.icon(
      onPressed: onPressed,
      style: TextButton.styleFrom(
        backgroundColor: Colors.grey[100],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      ),
      icon: Icon(icon, size: 16, color: AppColors.primary),
      label: Text(
        label,
        style: TextStyle(
          color: AppColors.primary,
          fontSize: 12,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  void onNextTabPressed() {
    if (_validateForm()) {
      if (medicationId.value.isEmpty) {
        medicationId.value = _generateId();
      }
      currentTab.value = 1;
      generateReminders();
    }
  }

  void onPreviousTabPressed() {
    currentTab.value = 0;
  }

  void onTimeSelected(TimeOfDay time) {
    addReminder(time);
  }

  bool _validateForm() {
    // if (!formKey.currentState!.validate()) return false;

    if (selectedMedicationFrequency.value == MedicationFrequency.custom) {
      // Validate custom days
      final days = int.tryParse(customDaysController.text);
      if (days == null || days <= 0) {
        Get.snackbar(
          'error'.tr,
          'please_enter_valid_days'.tr,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
        return false;
      }

      // Check if at least one day is selected
      if (!selectedDays.contains(true)) {
        Get.snackbar(
          'error'.tr,
          'please_select_at_least_one_day'.tr,
          backgroundColor: Colors.red,
          colorText: Colors.white,
        );
        return false;
      }
    }

    return true;
  }

  void resetForm() {
    nameController.clear();
    instructionsController.clear();
    doseQuantityController.clear();
    prescriptionDetailsController.clear();
  }

  MedicationModel toMedication() {
    final days = selectedDays.asMap()
        .entries
        .where((e) => e.value)
        .map((e) => DateTime(
      DateTime.now().year,
      DateTime.now().month,
      e.key + 1,
    ))
        .toList();

    return MedicationModel(
      id: medication.value.id,
      name: nameController.text,
      totalQuantity: int.tryParse(totalQuantityController.text) ?? 0,
      doseQuantity: int.tryParse(doseQuantityController.text) ?? 1,
      unit: selectedUnit.value,
      instructions: instructionsController.text,
      interactions: medication.value.interactions,
      hasPrescription: hasPrescription.value,
      prescriptionText: prescriptionDetailsController.text,
      prescriptionImage: prescriptionImageRx.value,
      imageUrl: medicationImageRx.value,
      expiryDate: expiryDate.value,
      frequency: selectedMedicationFrequency.value,
      createdAt: medication.value.createdAt ?? DateTime.now(),
      updatedAt: DateTime.now(),
    );
  }

  Future<void> editMedication() async {
    if (formKey.currentState!.validate()) {
      try {
        // Cancel existing reminders first
        // for (final reminder in medicationToEdit.value!.reminders) {
        //   await _notificationService.cancelReminder(reminder.id);
        // }
        //
        // final medicationModel = toMedication();
        //
        // await _medicationService.updateMedication(medicationModel);
        //
        // // Schedule new reminders
        // for (final reminder in reminders) {
        //   await _notificationService.scheduleReminder(reminder);
        // }

        Get.back(result: true);
        Get.snackbar(
          'success'.tr,
          'medication_updated'.tr,
          snackPosition: SnackPosition.BOTTOM,
        );
      } catch (e) {
        Get.snackbar(
          'error'.tr,
          'error_updating_medication'.tr,
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    }
  }

  // Reminder status helpers
  Color getReminderStatusColor(ReminderState state) {
    switch (state) {
      case ReminderState.taken:
        return Colors.green;
      case ReminderState.missed:
        return Colors.red;
      case ReminderState.skipped:
        return Colors.orange;
      case ReminderState.pending:
        return Colors.blue;
    }
  }

  String getReminderStatusText(ReminderState state) {
    switch (state) {
      case ReminderState.taken:
        return 'Taken';
      case ReminderState.missed:
        return 'Missed';
      case ReminderState.skipped:
        return 'Skipped';
      case ReminderState.pending:
        return 'Pending';
    }
  }

  IconData getReminderStatusIcon(ReminderState state) {
    switch (state) {
      case ReminderState.taken:
        return Icons.check_circle;
      case ReminderState.missed:
        return Icons.cancel;
      case ReminderState.skipped:
        return Icons.skip_next;
      case ReminderState.pending:
        return Icons.schedule;
    }
  }

  String getFormattedReminderTime(DateTime dateTime) {
    return DateFormat('hh:mm a').format(dateTime);
  }

  void toggleDay(int index) {
    selectedDays[index] = !selectedDays[index];
    selectedDays.refresh();
  }

  List<int> getSelectedDayIndices() {
    return selectedDays.asMap()
        .entries
        .where((e) => e.value)
        .map((e) => e.key + 1)
        .toList();
  }

  String get selectedDaysDescription {
    final days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    final selectedIndices = selectedDays.asMap()
        .entries
        .where((e) => e.value)
        .map((e) => days[e.key])
        .toList();

    if (selectedIndices.isEmpty) return 'No days selected';
    if (selectedIndices.length == 7) return 'Every day';
    return selectedIndices.join(', ');
  }

  // Prescription image handling
  Future<void> pickPrescriptionImage() async {
    try {
      final ImagePicker picker = ImagePicker();
      final XFile? image = await picker.pickImage(source: ImageSource.gallery);

      if (image != null) {
        final bytes = await image.readAsBytes();
        prescriptionImageRx.value = base64Encode(bytes);
      }
    } catch (e) {
      Logger().e('Error picking prescription image: $e');
    }
  }

  // Medication search
  void onSearchChanged(String value) {
    if (value.isEmpty) {
      searchResults.clear();
      return;
    }

    final results = SampleData.getSampleMedications()
        .where((med) => med.name.toLowerCase().contains(value.toLowerCase()))
        .toList();
    searchResults.value = results;
  }

  void onMedicationSelected(MedicationModel medication) {
    selectedMedication.value = medication;

    // Basic information
    medicationId.value = medication.id;
    nameController.text = medication.name;
    instructionsController.text = medication.instructions;
    doseQuantityController.text = medication.doseQuantity.toString();
    totalQuantityController.text = medication.totalQuantity.toString();
    selectedUnit.value = medication.unit;

    // Prescription information
    hasPrescription.value = medication.hasPrescription;
    if (medication.prescriptionText?.isNotEmpty ?? false) {
      prescriptionDetailsController.text = medication.prescriptionText!;
    }
    if (medication.prescriptionImage?.isNotEmpty ?? false) {
      prescriptionImageRx.value = medication.prescriptionImage!;
    }

    // Images
    if (medication.imageUrl?.isNotEmpty ?? false) {
      medicationImageRx.value = medication.imageUrl!;
    }

    // Interactions
    interactions.value = medication.interactions;

    // Clear search results
    searchResults.clear();

    // Show success message
    Get.snackbar(
      'Medication Selected',
      'Loaded ${medication.name} data successfully',
      backgroundColor: Colors.green,
      colorText: Colors.white,
      duration: const Duration(seconds: 1),
    );
  }

  // Frequency management
  void updateReminderFrequency(ReminderFrequency frequency) {
    selectedFrequency.value = frequency;
  }

  String getFrequencyLabel(ReminderFrequency frequency) {
    switch (frequency) {
      case ReminderFrequency.none:
        return '';
      case ReminderFrequency.daily:
        return 'Daily';
      case ReminderFrequency.weekly:
        return 'Weekly';
      case ReminderFrequency.monthly:
        return 'Monthly';
      case ReminderFrequency.custom:
        return 'Custom';
      default:
        return 'Unknown';
    }
  }

  void onReminderTypeSelected(ReminderType type) {
    final routineService = Get.find<RoutineService>();
    final routine = routineService.getRoutine();
    
    if (routine == null) {
      Get.snackbar(
        'Error',
        'Please set up your daily routine first',
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    TimeOfDay? selectedTime;
    
    switch (type) {
      case ReminderType.wakeUp:
        selectedTime = _parseTimeString(routine.wakeUpTime);
        break;
      case ReminderType.beforeBreakfast:
        selectedTime = (_parseTimeString(routine.breakfastTime));
        break;
      case ReminderType.afterBreakfast:
        selectedTime = (_parseTimeString(routine.breakfastTime));
        break;
      case ReminderType.beforeLunch:
        selectedTime = (_parseTimeString(routine.lunchTime));
        break;
      case ReminderType.afterLunch:
        selectedTime = (_parseTimeString(routine.lunchTime));
        break;
      case ReminderType.beforeDinner:
        selectedTime = (_parseTimeString(routine.dinnerTime));
        break;
      case ReminderType.afterDinner:
        selectedTime = (_parseTimeString(routine.dinnerTime));
        break;
      case ReminderType.bedtime:
        selectedTime = _parseTimeString(routine.bedTime);
        break;
      default:
        break;
    }

    if (selectedTime != null) {
      addReminder(selectedTime, type: type);
    }
  }

  TimeOfDay? _parseTimeString(String? timeString) {
    if (timeString == null) return null;
    final parts = timeString.split(':');
    if (parts.length != 2) return null;
    try {
      final hour = int.parse(parts[0]);
      final minute = int.parse(parts[1]);
      return TimeOfDay(hour: hour, minute: minute);
    } catch (e) {
      return null;
    }
  }

  TimeOfDay? _adjustTime(TimeOfDay? time, Duration offset) {
    if (time == null) return null;
    final now = DateTime.now();
    final dateTime = DateTime(
      now.year,
      now.month,
      now.day,
      time.hour,
      time.minute,
    );
    final adjustedDateTime = dateTime.add(offset);
    return TimeOfDay(hour: adjustedDateTime.hour, minute: adjustedDateTime.minute);
  }

  void updateReminderType(ReminderType type) {
    selectedReminderType.value = type;
  }

  void onExpiryReminderDaysChanged(int days) {
    selectedExpiryReminderDays.value = days;
    medication.update((val) {
      if (val != null) {
        val.expiryReminderDays = days;
      }
    });
  }

  void onQuantityReminderDaysChanged(int days) {
    selectedQuantityReminderDays.value = days;
    medication.update((val) {
      if (val != null) {
        val.quantityReminderDays = days;
      }
    });
  }

  void onFrequencyChanged(MedicationFrequency frequency) {
    selectedMedicationFrequency.value = frequency;
    if (frequency == MedicationFrequency.custom) {
      // Reset selected days when switching to custom
      selectedDays.value = List.generate(7, (index) => false);
    }
    
    // Update existing reminders based on new frequency
    _updateRemindersForFrequency(frequency);
  }

  void _updateRemindersForFrequency(MedicationFrequency frequency) {
    if (newReminders.isEmpty) return;

    final existingTimes = newReminders.map((r) => TimeOfDay(
      hour: r.dateTime.hour,
      minute: r.dateTime.minute
    )).toList();

    // Clear existing reminders
    newReminders.clear();

    // Create new reminders based on frequency
    switch (frequency) {
      case MedicationFrequency.daily:
        // Add reminder for every day
        for (final time in existingTimes) {
          final reminder = ReminderModel(
            id: _generateId(),
            medicationId: medicationId.value,
            medicationName: medication.value.name,
            dateTime: DateTime(
              DateTime.now().year,
              DateTime.now().month,
              DateTime.now().day,
              time.hour,
              time.minute,
            ),
            type: ReminderType.custom,
          );
          newReminders.add(reminder);
        }
        break;
      case MedicationFrequency.custom:
        // Add reminders only for selected days
        for (final time in existingTimes) {
          for (int i = 0; i < selectedDays.length; i++) {
            if (selectedDays[i]) {
              final now = DateTime.now();
              var reminderDate = now;
              // Find the next occurrence of this day (i + 1 because weekday is 1-based)
              while (reminderDate.weekday != i + 1) {
                reminderDate = reminderDate.add(const Duration(days: 1));
              }
              final reminder = ReminderModel(
                id: _generateId(),
                medicationId: medicationId.value,
                medicationName: medication.value.name,
                dateTime: DateTime(
                  reminderDate.year,
                  reminderDate.month,
                  reminderDate.day,
                  time.hour,
                  time.minute,
                ),
                type: ReminderType.custom,
              );
              newReminders.add(reminder);
            }
          }
        }
        break;
      default:
        // Handle other frequencies...
        break;
    }
  }

  Future<void> loadReminders(MedicationModel med) async {
    try {
      final reminders = await _customReminderController.reminders.where((p0) =>  p0.medicationId == medicationId.value).toList();
      
      // Convert existing reminders to TimeOfDay for frequency handling
      final times = reminders.map((r) => TimeOfDay(
        hour: r.dateTime.hour,
        minute: r.dateTime.minute
      )).toList();

      // Clear existing reminders
      newReminders.clear();

      // Create new reminders based on frequency
      if (times.isNotEmpty) {
        for (final time in times) {
          final reminder = ReminderModel(
            id: _generateId(),
            medicationId: medicationId.value,
            medicationName: medication.value.name,
            dateTime: DateTime(
              DateTime.now().year,
              DateTime.now().month,
              DateTime.now().day,
              time.hour,
              time.minute,
            ),
            type: med.frequency == MedicationFrequency.daily
              ? ReminderType.custom 
              : ReminderType.daily,
            statusHistory: [
              ReminderStatus(
                timestamp: DateTime.now(),
                state: ReminderState.pending,
              ),
            ],
          );
          newReminders.add(reminder);
        }
      }
    } catch (e) {
      _logger.e('Error loading reminders: $e');
    }
  }

  Future<List<ReminderModel>> _checkAndAdjustInteractions(List<ReminderModel> newReminders) async {
    try {
      final savedMedications = await _customMedicationController.medications;
      
      // Create a list with current medication and saved ones
      final allMedications = <MedicationModel>[medication.value];
      if (savedMedications != null) {
        allMedications.addAll(savedMedications!);
      }
      
      final optimalSchedule = _interactionService.findOptimalSchedule(allMedications);
      if (optimalSchedule != null) {
        // Handle optimal schedule
        // interactions.value = optimalSchedule.interactions;
        // Update reminders based on optimal schedule if needed
      }
      return newReminders;
    } catch (e) {
      _logger.e('Error checking interactions: $e');
      return newReminders;
    }
  }

  Future<void> generateReminders() async {
    try {
      isGeneratingReminders.value = true;
      
      // Start loading reminders
      final remindersFuture = () async {
        final sampleReminders = await SampleData.getSampleReminders();
        return sampleReminders
            .where((r) => r.medicationName == nameController.text)
            .toList();
      }();

      // Show generating dialog for at least 2 seconds
      Get.dialog(
        Dialog(
          backgroundColor: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Lottie.asset(
                  'assets/anim/reminders.json',
                  width: 150,
                  height: 150,
                ),
                const SizedBox(height: 20),
                Text(
                  'generating_reminders'.tr,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'generating_reminders_description'.tr,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey[600],
                  ),
                ),
              ],
            ),
          ),
        ),
        barrierDismissible: false,
      );

      // Wait for both the reminders and the minimum display time
      await Future.wait([
        remindersFuture,
        Future.delayed(const Duration(seconds: 2)),
      ]);

      // Close dialog and update reminders
      if (Get.isDialogOpen ?? false) {
        Get.back();
      }

      final medicationReminders = await remindersFuture;
      reminders.value = medicationReminders;

    } catch (e) {
      // Close generating dialog if error occurs
      if (Get.isDialogOpen ?? false) {
        Get.back();
      }
      
      Get.snackbar(
        'error'.tr,
        'error_generating_reminders'.tr,
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      isGeneratingReminders.value = false;
    }
  }

  void onSave() async {
    try {
      // Check for interactions before saving
      final adjustedReminders = await _checkAndAdjustInteractions(reminders);
      
      if (adjustedReminders != reminders) {
        // If reminders were adjusted, update them
        reminders.value = adjustedReminders;
        
        // Show success message
        Get.snackbar(
          'success'.tr,
          'reminders_adjusted'.tr,
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green[100],
        );
      }
      
      // TODO: Save the reminders
      Get.back();
    } catch (e) {
      Get.snackbar(
        'error'.tr,
        'error_saving_reminders'.tr,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }
}
