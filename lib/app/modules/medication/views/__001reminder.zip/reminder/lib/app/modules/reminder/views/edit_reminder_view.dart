import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/reminder_model.dart';
import '../controllers/reminder_controller.dart';

class EditReminderView extends GetView<ReminderController> {
  const EditReminderView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final reminder = Get.arguments as ReminderModel;
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Reminder'),
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () async {
              final confirmed = await Get.dialog<bool>(
                AlertDialog(
                  title: const Text('Delete Reminder'),
                  content: const Text('Are you sure you want to delete this reminder?'),
                  actions: [
                    TextButton(
                      onPressed: () => Get.back(result: false),
                      child: const Text('Cancel'),
                    ),
                    TextButton(
                      onPressed: () => Get.back(result: true),
                      child: const Text('Delete'),
                    ),
                  ],
                ),
              );

              if (confirmed == true) {
                final success = await controller.deleteReminder(reminder.id);
                if (success) {
                  Get.back();
                } else {
                  Get.snackbar(
                    'Error',
                    'Failed to delete reminder',
                    snackPosition: SnackPosition.BOTTOM,
                  );
                }
              }
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Reminder details
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Type: ${reminder.type.toString().split('.').last}',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Date: ${reminder.dateTime.toString().split(' ')[0]}',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                    Text(
                      'Time: ${reminder.dateTime.hour}:${reminder.dateTime.minute.toString().padLeft(2, '0')}',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 32),

            // Status update buttons
            Text(
              'Current Status: ${reminder.getCurrentState().toString().split('.').last}',
              style: const TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: ReminderStatus.values.map((status) {
                return ElevatedButton(
                  onPressed: reminder.getCurrentState() == status
                      ? null
                      : () async {
                          try {
                            await controller.updateReminderStatus(
                              reminder.id,
                              ReminderStatus(
                                timestamp: DateTime.now(),
                                state: status,
                              ),
                            );
                            Get.back();
                          } catch (e) {
                            Get.snackbar(
                              'Error',
                              'Failed to update reminder status',
                              backgroundColor: Colors.red,
                              colorText: Colors.white,
                            );
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: reminder.getCurrentState() == status
                        ? Colors.grey
                        : AppColors.primary,
                  ),
                  child: Text(status.toString().split('.').last),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
