import 'package:get/get.dart';
import 'package:logger/logger.dart';
import 'package:reminder/app/data/models/medication_model.dart';
import 'package:reminder/app/data/models/reminder_state.dart';
import 'package:reminder/app/data/models/reminder_status.dart';
import 'package:reminder/app/data/usecases/medication/get_all_medications_by_uid_usecase.dart';
import 'package:reminder/app/data/usecases/reminder/update_reminder_usecase.dart';
import 'package:workmanager/workmanager.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:torch_light/torch_light.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest.dart' as tz;
import 'dart:convert';
import '../data/models/reminder_model.dart';

import '../routes/app_pages.dart';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    try {
      switch (task) {
        case 'toggleTorch':
          final bool turnOn = inputData?['turnOn'] ?? false;
          if (turnOn) {
            await TorchLight.enableTorch();
            await Future.delayed(const Duration(seconds: 3));
            await TorchLight.disableTorch();
          }
          break;
      }
      return true;
    } catch (e) {
      print('Error in background task: $e');
      return false;
    }
  });
}

class ScheduleService extends GetxService {
  final _isScheduled = false.obs;
  final _selectedTime = Rxn<DateTime>();
  final _hasIgnoreBatteryOptimization = false.obs;
  final _isNotificationsEnabled = false.obs;
  final _isTorchEnabled = false.obs;
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  final GetMedicationByIdUseCase _medicationByIdUseCase;
  final GetReminderUseCase _getReminderUseCase;
  final UpdateReminderUseCase _updateReminderUseCase = Get.find();

  ScheduleService(this._medicationByIdUseCase, this._getReminderUseCase);

  bool get isScheduled => _isScheduled.value;
  DateTime? get selectedTime => _selectedTime.value;
  bool get hasIgnoreBatteryOptimization => _hasIgnoreBatteryOptimization.value;
  bool get isNotificationsEnabled => _isNotificationsEnabled.value;
  bool get isTorchEnabled => _isTorchEnabled.value;

  Future<ScheduleService> init() async {
    // Initialize timezone
    tz.initializeTimeZones();
    
    // Initialize Workmanager for background tasks
    await Workmanager().initialize(
      callbackDispatcher,
      isInDebugMode: false,
    );
    
    await _initializeNotifications();
    await _checkPermissions();
    await _checkNotificationSettings();
    return this;
  }

  Future<void> _initializeNotifications() async {
    const androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initializationSettings = InitializationSettings(android: androidSettings);
    
    await flutterLocalNotificationsPlugin.initialize(
      initializationSettings,
      onDidReceiveNotificationResponse: _handleNotificationResponse,
    );
  }

  Future<void> _handleNotificationResponse(NotificationResponse response) async {
    if (response.payload != null) {
      try {
        final data = json.decode(response.payload!);
        final reminderId = data['reminderId'];
        final medicationId = data['medicationId'];
        Logger().d(data);
        MedicationModel? medicationModel = await _medicationByIdUseCase.call(medicationId);
        ReminderModel? reminder = await _getReminderUseCase.call(reminderId);
        final action = response.actionId;

        switch (action) {
          case 'take':
            // Handle medication taken

            final currentDateYMDHS = DateTime.now();
            final selectedDate = DateTime(
              currentDateYMDHS.year,
              currentDateYMDHS.month,
              currentDateYMDHS.day,
            );

            final statusDateTime = DateTime(
              selectedDate.year,
              selectedDate.month,
              selectedDate.day,
              reminder!.dateTime.hour,
              reminder.dateTime.minute,
            );

            reminder.statusHistory.removeWhere((status) =>
            status.timestamp.year == selectedDate.year &&
                status.timestamp.month == selectedDate.month &&
                status.timestamp.day == selectedDate.day
            );

            reminder.statusHistory.add(ReminderStatus(
              timestamp: statusDateTime,
              state: ReminderState.taken,
            ));

            reminder.statusHistory.sort((a, b) =>
                a.timestamp.compareTo(b.timestamp)
            );

            await _updateReminderUseCase(reminder);

            break;
          case 'skip':
            // Handle medication skipped

            final currentDateYMDHS = DateTime.now();
            final selectedDate = DateTime(
              currentDateYMDHS.year,
              currentDateYMDHS.month,
              currentDateYMDHS.day,
            );

            final statusDateTime = DateTime(
              selectedDate.year,
              selectedDate.month,
              selectedDate.day,
              reminder!.dateTime.hour,
              reminder.dateTime.minute,
            );

            reminder.statusHistory.removeWhere((status) =>
            status.timestamp.year == selectedDate.year &&
                status.timestamp.month == selectedDate.month &&
                status.timestamp.day == selectedDate.day
            );

            reminder.statusHistory.add(ReminderStatus(
              timestamp: statusDateTime,
              state: ReminderState.skipped,
            ));

            reminder.statusHistory.sort((a, b) =>
                a.timestamp.compareTo(b.timestamp)
            );

            await _updateReminderUseCase(reminder);

            break;
          default:

        }
      } catch (e) {
        print('Error handling notification response: $e');
      }
    }
  }

  Future<void> _checkPermissions() async {
    // Check battery optimization status
    _hasIgnoreBatteryOptimization.value = await Permission.ignoreBatteryOptimizations.isGranted;

    // Request camera permission for torch
    var cameraStatus = await Permission.camera.status;
    if (!cameraStatus.isGranted) {
      cameraStatus = await Permission.camera.request();
    }

    // Request notification permission
    var notificationStatus = await Permission.notification.status;
    if (!notificationStatus.isGranted) {
      notificationStatus = await Permission.notification.request();
    }

    // Request exact alarm permission for Android 12 and above
    if (await Permission.scheduleExactAlarm.isRestricted) {
      await Permission.scheduleExactAlarm.request();
    }
  }

  Future<void> _checkNotificationSettings() async {
    _isNotificationsEnabled.value = true ?? false;
    _isTorchEnabled.value = await Permission.camera.isGranted;
  }

  Future<void> requestBatteryOptimizationPermission() async {
    if (!_hasIgnoreBatteryOptimization.value) {
      final status = await Permission.ignoreBatteryOptimizations.request();
      _hasIgnoreBatteryOptimization.value = status.isGranted;

      if (status.isGranted) {
        Get.snackbar(
          'Success',
          'Battery optimization disabled for reliable background operation',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.green.withOpacity(0.7),
          colorText: Colors.white,
          duration: const Duration(seconds: 3),
        );
      } else {
        Get.snackbar(
          'Warning',
          'Battery optimization may affect background tasks. Please disable it in system settings for reliable operation.',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.orange.withOpacity(0.7),
          colorText: Colors.white,
          duration: const Duration(seconds: 5),
        );
      }
    }
  }

  Future<bool> requestPermissions() async {
    // First request battery optimization
    await requestBatteryOptimizationPermission();

    Map<Permission, PermissionStatus> statuses = await [
      Permission.camera,
      Permission.notification,
      Permission.scheduleExactAlarm,
    ].request();

    bool allGranted = true;
    statuses.forEach((permission, status) {
      if (!status.isGranted) {
        allGranted = false;
      }
    });

    if (!allGranted) {
      Get.snackbar(
        'Permission Required',
        'Please grant all required permissions to schedule torch tasks',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.7),
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );
    }

    return allGranted;
  }

  Future<void> scheduleTorchTask(DateTime scheduledTime) async {
    if (!await requestPermissions()) {
      return;
    }

    // Additional check for battery optimization
    if (!_hasIgnoreBatteryOptimization.value) {
      Get.dialog(
        AlertDialog(
          title: const Text('Battery Optimization'),
          content: const Text(
              'For reliable background operation, it\'s recommended to disable battery optimization. '
                  'Would you like to disable it now?'
          ),
          actions: [
            TextButton(
              onPressed: () {
                Get.back();
                _scheduleTask(scheduledTime);
              },
              child: const Text('Skip'),
            ),
            ElevatedButton(
              onPressed: () async {
                Get.back();
                await requestBatteryOptimizationPermission();
                _scheduleTask(scheduledTime);
              },
              child: const Text('Disable Battery Optimization'),
            ),
          ],
        ),
      );
    } else {
      await _scheduleTask(scheduledTime);
    }
  }

  Future<void> _scheduleTask(DateTime scheduledTime) async {
    final now = DateTime.now();
    var targetTime = DateTime(
      now.year,
      now.month,
      now.day,
      scheduledTime.hour,
      scheduledTime.minute,
    );

    if (targetTime.isBefore(now)) {
      targetTime = targetTime.add(const Duration(days: 1));
    }

    final Duration initialDelay = targetTime.difference(now);

    try {
      await Workmanager().registerOneOffTask(
        'flashTorch${targetTime.millisecondsSinceEpoch}',
        'toggleTorch',
        initialDelay: initialDelay,
        inputData: {'turnOn': true},
      );

      _selectedTime.value = targetTime;
      _isScheduled.value = true;

      Get.snackbar(
        'Success',
        'Torch flash scheduled for ${targetTime.hour.toString().padLeft(2, '0')}:${targetTime.minute.toString().padLeft(2, '0')}',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green.withOpacity(0.7),
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to schedule torch task: $e',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.7),
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );
    }
  }

  Future<void> cancelScheduledTask() async {
    try {
      await Workmanager().cancelAll();
      _isScheduled.value = false;
      _selectedTime.value = null;

      Get.snackbar(
        'Success',
        'All scheduled tasks cancelled',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green.withOpacity(0.7),
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to cancel scheduled tasks: $e',
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.7),
        colorText: Colors.white,
        duration: const Duration(seconds: 3),
      );
    }
  }

  Future<void> scheduleReminder(ReminderModel reminder, String title, String body, {bool useTorch = false}) async {
    if (!_isNotificationsEnabled.value) {
      Get.snackbar(
        'Warning',
        'Notifications are disabled. Please enable them in system settings.',
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
      return;
    }

    if (useTorch && !_isTorchEnabled.value) {
      Get.snackbar(
        'Warning',
        'Torch light permission is not granted. Some features may be limited.',
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
    }

    var androidDetails = AndroidNotificationDetails(
      'medication_reminders',
      'Medication Reminders',
      channelDescription: 'Notifications for medication reminders',
      importance: Importance.max,
      priority: Priority.high,
      enableLights: true,
      enableVibration: true,
      actions: [
        AndroidNotificationAction(
          'take',
          'Take',
          showsUserInterface: true,
          cancelNotification: true,
        ),
        AndroidNotificationAction(
          'skip',
          'Skip',
          showsUserInterface: true,
          cancelNotification: true,
        ),
      ],
    );

    var platformDetails = NotificationDetails(android: androidDetails);
    
    try {
      final scheduledDate = tz.TZDateTime.from(reminder.dateTime, tz.local);
      final payload = json.encode({
        'reminderId': reminder.id,
        'medicationId': reminder.medicationId,
        'time': reminder.dateTime.toIso8601String(),
        // 'frequency': reminder.frequency.toString(),
      });
      
      await flutterLocalNotificationsPlugin.zonedSchedule(
        reminder.id.hashCode,
        title,
        body,
        scheduledDate,
        platformDetails,
        payload: payload,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
      );

      if (useTorch && _isTorchEnabled.value) {
        await scheduleTorchTask(reminder.dateTime);
      }

      Get.snackbar(
        'Success',
        'Reminder scheduled for ${reminder.dateTime.hour.toString().padLeft(2, '0')}:${reminder.dateTime.minute.toString().padLeft(2, '0')}',
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        'Failed to schedule reminder: $e',
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    }
  }
}
