import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:uuid/uuid.dart';
import '../../../core/theme/app_colors.dart';
import '../../../data/models/medication_model.dart';
import '../../../data/models/reminder_model.dart';
import '../../../data/models/interaction_model.dart';
import '../controllers/custom_medication_contoller.dart';
import '../controllers/medications_controller.dart';

class MedicationsView extends GetView<MedicationsController> {
  MedicationsView({Key? key}) : super(key: key);

  final CustomMedicationController medicationController = Get.find();
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: Get.locale?.languageCode == 'ar' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: AppColors.background,
        body: Obx(() {
          if (medicationController.isLoading.value) {
            return const Center(child: CircularProgressIndicator());
          }

          if (medicationController.medications.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.medication_outlined,
                      size: 64,
                      color: AppColors.primary,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'no_medications'.tr,
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      color: AppColors.textLight,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'add_medication_hint'.tr,
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      color: AppColors.textLight,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: medicationController.medications.length,
            itemBuilder: (context, index) {
              final medication = medicationController.medications[index];
              return _buildMedicationCard(medication);
            },
          );
        }),
        floatingActionButton: FloatingActionButton(
          onPressed: () => Get.toNamed('/add-medication'),
          backgroundColor: AppColors.primary,
          child: const Icon(Icons.add, color: Colors.white),
        ),
      ),
    );
  }

  Widget _buildMedicationCard(MedicationModel medication) {
    final isExpired = controller.isExpired(medication.expiryDate);

    return Card(
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 16),
      child: Theme(
        data: Theme.of(Get.context!).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          title: Row(
            children: [
              Expanded(
                child: Text(
                  medication.name,
                  style: GoogleFonts.poppins(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              if (isExpired)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'expired'.tr,
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      color: Colors.red,
                    ),
                  ),
                ),
            ],
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${medication.doseQuantity} ${medication.unit} ${'per_dose'.tr}',
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  color: AppColors.textLight,
                ),
              ),
              if (medication.expiryDate != null)
                Text(
                  '${'expires'.tr}: ${controller.formatDate(medication.expiryDate)}',
                  style: GoogleFonts.poppins(
                    fontSize: 12,
                    color: isExpired ? Colors.red : AppColors.textLight,
                  ),
                ),
            ],
          ),
          leading: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Image.asset(medication.imageUrl!,fit: BoxFit.cover,)
          ),
          trailing: IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () => controller.showMedicationOptions(medication),
          ),
          children: [
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (medication.instructions.isNotEmpty) ...[
                    Text(
                      'instructions'.tr,
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      medication.instructions,
                      style: GoogleFonts.poppins(fontSize: 14),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Quantity Section
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'total_quantity'.tr,
                              style: GoogleFonts.poppins(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            Text(
                              '${medication.totalQuantity} ${medication.unit}',
                              style: GoogleFonts.poppins(fontSize: 14),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'remaining'.tr,
                              style: GoogleFonts.poppins(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            FutureBuilder<int>(
                              future: controller.calculateTakenReminders(medication.id),
                              builder: (context, snapshot) {
                                if (snapshot.connectionState == ConnectionState.waiting) {
                                  return const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(strokeWidth: 2),
                                  );
                                }
                                
                                final takenQuantity = snapshot.data ?? 0;

                                final remainingQuantity = medication.totalQuantity - takenQuantity;
                                
                                return Text(
                                  '${remainingQuantity} ${medication.unit}',
                                  style: GoogleFonts.poppins(
                                    fontSize: 14,
                                    color: remainingQuantity <= 5
                                        ? Colors.red
                                        : AppColors.textLight,
                                  ),
                                );
                              },
                            )
                          ],
                        ),
                      ),
                    ],
                  ),

                  // Interactions Section
                  if (medication.interactions.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Text(
                      'interactions'.tr,
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...medication.interactions.map((interaction) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(
                            Icons.warning,
                            color: _getInteractionColor(interaction),
                          ),
                          title: Text(
                            interaction.medicationName,
                            style: GoogleFonts.poppins(
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                interaction.description,
                                style: GoogleFonts.poppins(fontSize: 12),
                              ),
                              Text(
                                'recommendation'.tr + ': ${interaction.recommendation}',
                                style: GoogleFonts.poppins(
                                  fontSize: 12,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                            ],
                          ),
                        )),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getInteractionColor(InteractionModel interaction) {
    switch (interaction.riskLevel) {
      case RiskLevel.high:
        return Colors.red;
      case RiskLevel.moderate:
        return Colors.orange;
      case RiskLevel.low:
        return Colors.yellow;
      case RiskLevel.none:
        return Colors.green;
    }
  }
}
