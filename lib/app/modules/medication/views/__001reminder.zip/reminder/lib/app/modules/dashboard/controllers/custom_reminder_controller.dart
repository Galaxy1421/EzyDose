import 'package:get/get.dart';
import 'package:meta/meta.dart';
import 'package:reminder/app/data/usecases/reminder/add_reminder_usecase.dart';
import 'package:reminder/app/data/usecases/reminder/delete_reminder_usecase.dart';
import 'package:reminder/app/data/usecases/reminder/get_all_reminders_by_medcations_id_usecase.dart';
import 'package:reminder/app/data/usecases/reminder/get_all_reminders_usecase.dart';
import 'package:reminder/app/data/usecases/reminder/update_reminder_usecase.dart';
import 'package:reminder/app/data/models/reminder_model.dart';

class CustomReminderController extends GetxController {
  final AddReminderUseCase _addReminderUseCase;
  final UpdateReminderUseCase _updateReminderUseCase;
  final DeleteReminderUsecase _deleteReminderUseCase;
  final DeleteMedicationRemindersUseCase _deleteMedicationRemindersUseCase;
  final GetAllRemindersUsecase _allRemindersUseCase;
  final GetReminderUseCase _getReminderUseCase;
  final GetAllRemindersByMedicationsIdUseCase _allRemindersByMedicationsIdUseCase;

  CustomReminderController({
    required AddReminderUseCase addReminderUseCase,
    required UpdateReminderUseCase updateReminderUseCase,
    required DeleteReminderUsecase deleteReminderUseCase,
    required GetReminderUseCase getReminderUseCase,
    required GetAllRemindersUsecase allRemindersUseCase,
    required DeleteMedicationRemindersUseCase deleteMedicationRemindersUseCase,
    required GetAllRemindersByMedicationsIdUseCase allRemindersByMedicationsIdUseCase,
  })  : _addReminderUseCase = addReminderUseCase,
        _updateReminderUseCase = updateReminderUseCase,
        _getReminderUseCase = getReminderUseCase,
        _deleteReminderUseCase = deleteReminderUseCase,
        _allRemindersUseCase = allRemindersUseCase,
        _deleteMedicationRemindersUseCase = deleteMedicationRemindersUseCase,

        _allRemindersByMedicationsIdUseCase = allRemindersByMedicationsIdUseCase;

  final RxBool isLoading = false.obs;
  final RxList<ReminderModel> reminders = <ReminderModel>[].obs;
  final Rx<String?> errorMessage = Rx<String?>(null);

  @override
  void onInit() {
    super.onInit();
    getAllReminders();
  }

  Future<void> getAllReminders() async {
    _loadingWrapper(() async {
      final result = await _allRemindersUseCase();
      reminders.assignAll(result);
    }, 'Failed to get reminders');
  }

  Future<List<ReminderModel>> getRemindersByMedicationId(String medicationId) async {
    try {
      isLoading.value = true;
      errorMessage.value = null;
      final result = await _allRemindersByMedicationsIdUseCase(medicationId);
      reminders.assignAll(result);
      return result;
    } catch (e) {
      errorMessage.value = 'Failed to get reminders for medication: $e';
      _showErrorDialog(errorMessage.value!);
      return [];
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> addReminder(ReminderModel reminder) async {
    await _loadingWrapper(() async {
      await _addReminderUseCase(reminder);
      await getAllReminders();
      _showSuccessDialog('Reminder added successfully');
    }, 'Failed to add reminder');
  }

  Future<void> updateReminder(ReminderModel reminder) async {
    await _loadingWrapper(() async {
      await _updateReminderUseCase(reminder);
      await getAllReminders();
      _showSuccessDialog('Reminder updated successfully');
    }, 'Failed to update reminder');
  }

  Future<void> deleteReminder(ReminderModel reminder) async {
    await _loadingWrapper(() async {
      await _deleteReminderUseCase(reminder);
      await getAllReminders();
      _showSuccessDialog('Reminder deleted successfully');
    }, 'Failed to delete reminder');
  }

  Future<void> _loadingWrapper(Future<void> Function() action, String errorMsg) async {
    try {
      isLoading.value = true;
      errorMessage.value = null;
      await action();
    } catch (e) {
      errorMessage.value = '$errorMsg: $e';
      _showErrorDialog(errorMessage.value!);
    } finally {
      isLoading.value = false;
    }
  }

  void _showSuccessDialog(String message) {
    Get.snackbar(
      'Success',
      message,
      snackPosition: SnackPosition.BOTTOM,
      duration: Duration(seconds: 3),
    );
  }

  void _showErrorDialog(String message) {
    Get.snackbar(
      'Error',
      message,
      snackPosition: SnackPosition.BOTTOM,
      duration: Duration(seconds: 3),
      backgroundColor: Get.theme.primaryColor,
      colorText: Get.theme.colorScheme.onError,
    );
  }
}