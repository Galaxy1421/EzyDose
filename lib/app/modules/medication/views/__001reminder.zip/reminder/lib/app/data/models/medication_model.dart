import 'package:flutter/material.dart';
import 'package:logger/logger.dart';
import '../services/settings_service.dart';
import 'package:reminder/app/data/models/interaction_model.dart';
import 'package:reminder/app/data/models/reminder_model.dart';
import 'package:get/get.dart';
import 'dart:convert'; // Import dart:convert for jsonEncode and jsonDecode

enum MedicationFrequency {
  daily,
  once,
  weekly,
  monthly,
  yearly,
  never,
  custom
}

class MedicationModel {
  static const int defaultLowQuantityThreshold = 5;

  String id;
  String name;
  String instructions;
  int totalQuantity;
  int remainingQuantity;
  int doseQuantity;
  String unit;
  List<InteractionModel> interactions;
  String? imageUrl;
  bool hasPrescription;
  String? prescriptionText;
  String? prescriptionImage;
  DateTime? expiryDate;
  DateTime createdAt;
  DateTime updatedAt;
  MedicationFrequency frequency;
  String? dosage;
  String? notes;
  DateTime? prescriptionDate;
  String? doctorName;
  String? imageBase64;
  int? expiryReminderDays;
  int? quantityReminderDays;

  MedicationModel({
    required this.id,
    required this.name,
    this.instructions = '',
    required this.totalQuantity,
    required this.doseQuantity,
    required this.unit,
    this.interactions = const [],
    this.imageUrl,
    this.hasPrescription = false,
    this.prescriptionText,
    this.prescriptionImage,
    this.expiryDate,
    DateTime? createdAt,
    DateTime? updatedAt,
    int? remainingQuantity,
    this.frequency = MedicationFrequency.daily,
    this.dosage,
    this.notes,
    this.prescriptionDate,
    this.doctorName,
    this.imageBase64,
    this.expiryReminderDays = 7,
    this.quantityReminderDays = 7,
  }) : 
    this.createdAt = createdAt ?? DateTime.now(),
    this.updatedAt = updatedAt ?? DateTime.now(),
    this.remainingQuantity = remainingQuantity ?? totalQuantity;

  // Get the quantity display string (e.g., "58/60 pills")
  String get quantityDisplay => '$remainingQuantity/$totalQuantity $unit';

  // Get the next refill date based on remaining quantity and dose quantity
  DateTime? get nextRefillDate {
    if (remainingQuantity <= 0 || doseQuantity <= 0) return null;
    
    final daysRemaining = remainingQuantity ~/ doseQuantity;
    return DateTime.now().add(Duration(days: daysRemaining));
  }

  // Check if medication is running low based on threshold
  bool get isRunningLow {
    if (remainingQuantity <= 0 || doseQuantity <= 0) return true;
    
    final daysRemaining = remainingQuantity ~/ doseQuantity;
    return daysRemaining <= defaultLowQuantityThreshold;
  }

  // Create a copy of this medication with updated values
  MedicationModel copyWith({
    String? id,
    String? name,
    String? instructions,
    int? totalQuantity,
    int? remainingQuantity,
    int? doseQuantity,
    String? unit,
    List<InteractionModel>? interactions,
    String? imageUrl,
    bool? hasPrescription,
    String? prescriptionText,
    String? prescriptionImage,
    DateTime? expiryDate,
    DateTime? createdAt,
    DateTime? updatedAt,
    MedicationFrequency? frequency,
    String? dosage,
    String? notes,
    DateTime? prescriptionDate,
    String? doctorName,
    String? imageBase64,
    int? expiryReminderDays,
    int? quantityReminderDays,
  }) {
    return MedicationModel(
      id: id ?? this.id,
      name: name ?? this.name,
      instructions: instructions ?? this.instructions,
      totalQuantity: totalQuantity ?? this.totalQuantity,
      remainingQuantity: remainingQuantity ?? this.remainingQuantity,
      doseQuantity: doseQuantity ?? this.doseQuantity,
      unit: unit ?? this.unit,
      interactions: interactions ?? this.interactions,
      imageUrl: imageUrl ?? this.imageUrl,
      hasPrescription: hasPrescription ?? this.hasPrescription,
      prescriptionText: prescriptionText ?? this.prescriptionText,
      prescriptionImage: prescriptionImage ?? this.prescriptionImage,
      expiryDate: expiryDate ?? this.expiryDate,
      frequency: frequency ?? this.frequency,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      dosage: dosage ?? this.dosage,
      notes: notes ?? this.notes,
      prescriptionDate: prescriptionDate ?? this.prescriptionDate,
      doctorName: doctorName ?? this.doctorName,
      imageBase64: imageBase64 ?? this.imageBase64,
      expiryReminderDays: expiryReminderDays ?? this.expiryReminderDays,
      quantityReminderDays: quantityReminderDays ?? this.quantityReminderDays,
    );
  }

  factory MedicationModel.fromJson(Map<String, dynamic> json) {
    try {
      return MedicationModel(
        id: json['id'] as String,
        name: json['name'] as String,
        instructions: json['instructions'] as String? ?? '',
        totalQuantity: json['totalQuantity'] as int? ?? 0,
        remainingQuantity: json['remainingQuantity'] as int?,
        doseQuantity: json['doseQuantity'] as int? ?? 1,
        unit: json['unit'] as String? ?? 'pills',
        interactions: (json['interactions'] as List<dynamic>?)
                ?.map((e) => InteractionModel.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
        imageUrl: json['imageUrl'] as String?,
        hasPrescription: json['hasPrescription'] as bool? ?? false,
        prescriptionText: json['prescriptionText'] as String?,
        prescriptionImage: json['prescriptionImage'] as String?,
        expiryDate: json['expiryDate'] != null ? DateTime.parse(json['expiryDate']) : null,
        createdAt: json['createdAt'] != null ? DateTime.parse(json['createdAt']) : DateTime.now(),
        updatedAt: json['updatedAt'] != null ? DateTime.parse(json['updatedAt']) : DateTime.now(),
        frequency: json['frequency'] == 'daily' ? MedicationFrequency.daily : MedicationFrequency.weekly,
        dosage: json['dosage'] as String?,
        notes: json['notes'] as String?,
        prescriptionDate: json['prescriptionDate'] != null
            ? DateTime.parse(json['prescriptionDate'] as String)
            : null,
        doctorName: json['doctorName'] as String?,
        imageBase64: json['imageBase64'] as String?,
        expiryReminderDays: json['expiryReminderDays'] ?? 7,
        quantityReminderDays: json['quantityReminderDays'] ?? 7,
      );
    } catch (e, stack) {
      Logger().e('Error creating MedicationModel from JSON: $e\n$stack');
      rethrow;
    }
  }

  Map<String, dynamic> toJson() {
    try {
      final json = {
        'id': id,
        'name': name,
        'instructions': instructions,
        'totalQuantity': totalQuantity,
        'doseQuantity': doseQuantity,
        'unit': unit,
        'interactions': interactions.map((e) => e.toJson()).toList(),
        if (imageUrl != null) 'imageUrl': imageUrl,
        'hasPrescription': hasPrescription,
        if (prescriptionText != null) 'prescriptionText': prescriptionText,
        if (prescriptionImage != null) 'prescriptionImage': prescriptionImage,
        if (expiryDate != null) 'expiryDate': expiryDate!.toIso8601String(),
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'remainingQuantity': remainingQuantity,
        'frequency': frequency == MedicationFrequency.daily ? 'daily' : 'custom',
        if (dosage != null) 'dosage': dosage,
        if (notes != null) 'notes': notes,
        if (prescriptionDate != null)
          'prescriptionDate': prescriptionDate!.toIso8601String(),
        if (doctorName != null) 'doctorName': doctorName,
        if (imageBase64 != null) 'imageBase64': imageBase64,
        'expiryReminderDays': expiryReminderDays,
        'quantityReminderDays': quantityReminderDays,
      };
      return json;
    } catch (e, stack) {
      Logger().e('Error converting MedicationModel to JSON: $e\n$stack');
      rethrow;
    }
  }
}
