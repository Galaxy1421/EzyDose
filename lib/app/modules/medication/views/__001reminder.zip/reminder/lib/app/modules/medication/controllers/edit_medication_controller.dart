import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/medication_model.dart';
import '../../../data/models/reminder_model.dart';
import '../../../data/usecases/medication/update_medication_usecase.dart';
import '../../../data/usecases/reminder/update_reminder_usecase.dart';
import '../../../data/models/interaction_model.dart';

class EditMedicationController extends GetxController {
  final UpdateMedicationUseCase _updateMedicationUseCase;
  final UpdateReminderUseCase _updateReminderUseCase;

  EditMedicationController({
    required UpdateMedicationUseCase updateMedicationUseCase,
    required UpdateReminderUseCase updateReminderUseCase,
  })  : _updateMedicationUseCase = updateMedicationUseCase,
        _updateReminderUseCase = updateReminderUseCase;

  final formKey = GlobalKey<FormState>();
  final currentTab = 0.obs;
  final isLoading = false.obs;
  final errorMessage = Rx<String?>(null);

  // Form controllers
  final nameController = TextEditingController();
  final instructionsController = TextEditingController();
  final totalQuantityController = TextEditingController();
  final doseQuantityController = TextEditingController();
  final unitController = TextEditingController();
  final expiryDateController = TextEditingController();

  // Observable values
  final medication = Rx<MedicationModel?>(null);
  final reminders = <ReminderModel>[].obs;
  final selectedImage = Rx<String?>(null);
  final selectedPrescriptionImage = Rx<String?>(null);
  final interactions = <InteractionModel>[].obs;
  final expiryDate = Rx<DateTime?>(null);

  @override
  void onInit() {
    super.onInit();
    if (Get.arguments != null && Get.arguments is MedicationModel) {
      loadMedication(Get.arguments as MedicationModel);
    }
  }

  void loadMedication(MedicationModel med) {
    medication.value = med;
    nameController.text = med.name;
    instructionsController.text = med.instructions;
    totalQuantityController.text = med.totalQuantity.toString();
    doseQuantityController.text = med.doseQuantity.toString();
    unitController.text = med.unit;
    expiryDate.value = med.expiryDate;
    if (med.expiryDate != null) {
      expiryDateController.text = med.expiryDate.toString();
    }
    selectedImage.value = med.imageUrl;
    selectedPrescriptionImage.value = med.prescriptionImage;
    interactions.assignAll(med.interactions);
    // reminders.assignAll(med.reminders ?? []);
  }

  Future<void> updateMedication() async {
    if (!formKey.currentState!.validate()) return;

    try {
      isLoading.value = true;
      errorMessage.value = null;

      final updatedMedication = medication.value!.copyWith(
        name: nameController.text,
        instructions: instructionsController.text,
        totalQuantity: int.parse(totalQuantityController.text),
        doseQuantity: int.parse(doseQuantityController.text),
        unit: unitController.text,
        expiryDate: expiryDate.value,
        imageUrl: selectedImage.value,
        prescriptionImage: selectedPrescriptionImage.value,
        interactions: interactions,
        // reminders: reminders,
        updatedAt: DateTime.now(),
      );

      await _updateMedicationUseCase(updatedMedication);
      
      // Update reminders if changed
      for (var reminder in reminders) {
        await _updateReminderUseCase(reminder);
      }

      Get.back(result: true);
      Get.snackbar(
        'success'.tr,
        'medication_updated'.tr,
        snackPosition: SnackPosition.BOTTOM,
      );
    } catch (e) {
      errorMessage.value = e.toString();
      Get.snackbar(
        'error'.tr,
        'update_medication_error'.tr,
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red,
        colorText: Colors.white,
      );
    } finally {
      isLoading.value = false;
    }
  }

  void addReminder(TimeOfDay time, {required ReminderType type}) {
    // final reminder = ReminderModel(
    //   id: DateTime.now().millisecondsSinceEpoch.toString(),
    //   medicationId: medication.value!.id,
    //   medicationName: medication.value!.name,
    //   time: DateTime(
    //     DateTime.now().year,
    //     DateTime.now().month,
    //     DateTime.now().day,
    //     time.hour,
    //     time.minute,
    //   ),
    //   type: type,
    //   createdAt: DateTime.now(),
    //   updatedAt: DateTime.now(),
    //   statusHistory: [],
    // );
    // reminders.add(reminder);
  }

  void removeReminder(int index) {
    reminders.removeAt(index);
  }

  void addInteraction(InteractionModel interaction) {
    interactions.add(interaction);
  }

  void removeInteraction(int index) {
    interactions.removeAt(index);
  }

  @override
  void onClose() {
    nameController.dispose();
    instructionsController.dispose();
    totalQuantityController.dispose();
    doseQuantityController.dispose();
    unitController.dispose();
    expiryDateController.dispose();
    super.onClose();
  }
}
