part of 'app_routes.dart';

abstract class ReminderRoutes {
  static const REMINDER = '/reminder';
  static const ADD_REMINDER = '/add-reminder';
  static const EDIT_REMINDER = '/edit-reminder';
}
