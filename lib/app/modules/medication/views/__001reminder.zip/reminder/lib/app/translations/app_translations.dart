import 'package:get/get.dart';
import 'en.dart';
import 'ar.dart';


class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        'en': {
          ...en,
          'doctor_prescriptions': 'Doctor Prescriptions',
          'no_prescriptions': 'No prescriptions found',
          'prescription_date': 'Prescription Date',
          'doctor': 'Doctor',
          'notes': 'Notes',
          'notifications': 'Notifications',
          'history': 'History',
          'success': 'Success',
          'error': 'Error',
          'edit_profile': 'Edit Profile',
          'name': 'Name',
          'save': 'Save',
          'take_photo': 'Take Photo',
          'choose_from_gallery': 'Choose from Gallery',
          'remove_photo': 'Remove Photo',
          'enable_notifications': 'Enable Notifications',
          'notification_description': 'Get reminders for medications and appointments',
          'enable_flash': 'Enable Camera Flash',
          'flash_description': 'Use flash for better photo quality',
          'language_changed': 'Language changed successfully',
          'language_change_failed': 'Failed to change language',
          'profile_updated': 'Profile updated successfully',
          'update_failed': 'Failed to update profile',
        },
        'ar': {
          ...ar,
          'doctor_prescriptions': 'وصفات الطبيب',
          'no_prescriptions': 'لا توجد وصفات طبية',
          'prescription_date': 'تاريخ الوصفة',
          'doctor': 'الطبيب',
          'notes': 'ملاحظات',
          'notifications': 'الإشعارات',
          'history': 'السجل',
          'success': 'نجاح',
          'error': 'خطأ',
          'edit_profile': 'تعديل الملف الشخصي',
          'name': 'الاسم',
          'save': 'حفظ',
          'take_photo': 'التقاط صورة',
          'choose_from_gallery': 'اختيار من المعرض',
          'remove_photo': 'إزالة الصورة',
          'enable_notifications': 'تفعيل الإشعارات',
          'notification_description': 'احصل على تذكيرات للأدوية والمواعيد',
          'enable_flash': 'تفعيل فلاش الكاميرا',
          'flash_description': 'استخدم الفلاش لجودة عند التنبية',
          'language_changed': 'تم تغيير اللغة بنجاح',
          'language_change_failed': 'فشل في تغيير اللغة',
          'profile_updated': 'تم تحديث الملف الشخصي بنجاح',
          'update_failed': 'فشل تحديث الملف الشخصي',
        },
      };
}
