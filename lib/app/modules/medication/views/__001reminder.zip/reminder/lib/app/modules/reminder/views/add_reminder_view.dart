import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../data/models/reminder_model.dart';
import '../controllers/reminder_controller.dart';

class AddReminderView extends GetView<ReminderController> {
  const AddReminderView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final medicationId = Get.arguments as String;
    final selectedDate = DateTime.now().obs;
    final selectedTime = TimeOfDay.now().obs;
    final selectedType = ReminderType.custom.obs;
    final selectedFrequency = ReminderFrequency.daily.obs;
    final selectedDays = <int>[].obs;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Reminder'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Date picker
            ListTile(
              title: const Text('Date'),
              subtitle: Obx(() => Text(selectedDate.value.toString().split(' ')[0])),
              trailing: const Icon(Icons.calendar_today),
              onTap: () async {
                final picked = await showDatePicker(
                  context: context,
                  initialDate: selectedDate.value,
                  firstDate: DateTime.now(),
                  lastDate: DateTime.now().add(const Duration(days: 365)),
                );
                if (picked != null) {
                  selectedDate.value = picked;
                }
              },
            ),

            // Time picker
            ListTile(
              title: const Text('Time'),
              subtitle: Obx(() => Text(selectedTime.value.format(context))),
              trailing: const Icon(Icons.access_time),
              onTap: () async {
                final picked = await showTimePicker(
                  context: context,
                  initialTime: selectedTime.value,
                );
                if (picked != null) {
                  selectedTime.value = picked;
                }
              },
            ),

            // Reminder type dropdown
            ListTile(
              title: const Text('Type'),
              subtitle: Obx(() => Text(selectedType.value.toString().split('.').last)),
              trailing: const Icon(Icons.arrow_drop_down),
              onTap: () {
                Get.bottomSheet(
                  Container(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: ReminderType.values.length,
                      itemBuilder: (context, index) {
                        final type = ReminderType.values[index];
                        return ListTile(
                          title: Text(type.toString().split('.').last),
                          onTap: () {
                            selectedType.value = type;
                            Get.back();
                          },
                        );
                      },
                    ),
                  ),
                );
              },
            ),

            // Frequency picker
            ListTile(
              title: const Text('Frequency'),
              subtitle: Obx(() => Text(selectedFrequency.value.toString().split('.').last)),
              trailing: const Icon(Icons.repeat),
              onTap: () {
                Get.bottomSheet(
                  Container(
                    color: Theme.of(context).scaffoldBackgroundColor,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: ReminderFrequency.values.length,
                      itemBuilder: (context, index) {
                        final frequency = ReminderFrequency.values[index];
                        return ListTile(
                          title: Text(frequency.toString().split('.').last),
                          onTap: () {
                            selectedFrequency.value = frequency;
                            if (frequency == ReminderFrequency.custom && selectedDays.isEmpty) {
                              selectedDays.addAll([1, 2, 3, 4, 5]); // Mon-Fri by default
                            }
                            Get.back();
                          },
                        );
                      },
                    ),
                  ),
                );
              },
            ),

            // Custom days selector (only show if frequency is custom)
            Obx(() {
              if (selectedFrequency.value == ReminderFrequency.custom) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text('Repeat on:', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                      Wrap(
                        spacing: 4,
                        children: [
                          for (int i = 1; i <= 7; i++)
                            FilterChip(
                              label: Text(_getDayName(i)),
                              selected: selectedDays.contains(i),
                              onSelected: (selected) {
                                if (selected) {
                                  selectedDays.add(i);
                                } else {
                                  selectedDays.remove(i);
                                }
                              },
                            ),
                        ],
                      ),
                    ],
                  ),
                );
              }
              return const SizedBox.shrink();
            }),

            const SizedBox(height: 32),

            // Save button
            ElevatedButton(
              onPressed: () async {
                if (selectedFrequency.value == ReminderFrequency.custom && selectedDays.isEmpty) {
                  Get.snackbar(
                    'Error',
                    'Please select at least one day for custom frequency',
                    snackPosition: SnackPosition.BOTTOM,
                  );
                  return;
                }

                final dateTime = DateTime(
                  selectedDate.value.year,
                  selectedDate.value.month,
                  selectedDate.value.day,
                  selectedTime.value.hour,
                  selectedTime.value.minute,
                );

                final success = await controller.createReminder(
                  ReminderModel(
                    id: DateTime.now().millisecondsSinceEpoch.toString(),
                    medicationId: medicationId,
                    dateTime: dateTime,
                    type: selectedType.value,
                    status: ReminderStatus.pending,
                  ),
                );

                if (success) {
                  Get.back();
                } else {
                  Get.snackbar(
                    'Error',
                    'Failed to create reminder',
                    snackPosition: SnackPosition.BOTTOM,
                  );
                }
              },
              child: const Text('Save Reminder'),
            ),
          ],
        ),
      ),
    );
  }

  String _getDayName(int day) {
    switch (day) {
      case 1: return 'Mon';
      case 2: return 'Tue';
      case 3: return 'Wed';
      case 4: return 'Thu';
      case 5: return 'Fri';
      case 6: return 'Sat';
      case 7: return 'Sun';
      default: return '';
    }
  }
}
