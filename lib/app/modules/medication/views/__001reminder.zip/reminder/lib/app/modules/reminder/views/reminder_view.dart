import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../routes/app_pages.dart';
import '../controllers/reminder_controller.dart';

class ReminderView extends GetView<ReminderController> {
  const ReminderView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reminders'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => Get.toNamed(Routes.ADD_REMINDER),
          ),
        ],
      ),
      body: Obx(
        () => controller.isLoading.value
            ? const Center(child: CircularProgressIndicator())
            : controller.error.value != null
                ? Center(child: Text(controller.error.value!))
                : controller.reminders.isEmpty
                    ? const Center(child: Text('No reminders found'))
                    : ListView.builder(
                        itemCount: controller.reminders.length,
                        itemBuilder: (context, index) {
                          final reminder = controller.reminders[index];
                          return ListTile(
                            title: Text('Reminder ${reminder.id}'),
                            subtitle: Text(
                                '${reminder.type.toString().split('.').last} - ${reminder.dateTime.toString()}'),
                            trailing: Text(reminder.getCurrentState().toString().split('.').last),
                            onTap: () => Get.toNamed(
                              Routes.EDIT_REMINDER,
                              arguments: reminder,
                            ),
                          );
                        },
                      ),
      ),
    );
  }
}
